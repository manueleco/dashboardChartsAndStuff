$('.datepicker').datepicker(); // DatePicker
$('.sidenav').sidenav(); //Side bar
$('.fixed-action-btn').floatingActionButton();
$('.modal').modal(); //Inicializar todos los modales
$('.trigger-modal').modal(); //Al presionar un boton o link se dispara
$('.materialboxed').materialbox();
$('.tooltipped').tooltip();
$('.collapsible').collapsible();

$('.chips').chips();
  $('.chips-initial').chips({
    data: [{
      tag: 'Apple',
    }, {
      tag: 'Microsoft',
    }, {
      tag: 'Google',
    }],
  });
  $('.chips-placeholder').chips({
    placeholder: 'Enter a tag',
    secondaryPlaceholder: '+Tag',
  });
  $('.chips-autocomplete').chips({
    autocompleteOptions: {
      data: {
        'FAJAS': null,
        'RODILLOSPKS': null,
        'TROQUELES': null,
        'CLISHES': null,
        'HEBILLAS': null,
        'HANGERS': null,
        'PASADORES': null,
        'TICKETS': null
      },
      limit: Infinity,
      minLength: 1
    }
  });