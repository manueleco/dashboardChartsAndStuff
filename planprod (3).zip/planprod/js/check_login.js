$(document).on("ready", function(){
    $("#usuario").focus();
});

function enterLogin(e) {
    tecla = (document.all) ? e.keyCode : e.which;
    if (tecla==13) {
        login();
    }
}

function AlertToast(message,icon,color){
    var toastHTML = '<span>'+message+'&nbsp;</span><i class="material-icons'+' '+color+'-text'+'">'+icon+'</i>';
    return M.toast({html: toastHTML, classes: 'rounded'});
}

function clear(){
    $('#usuario').val('');
    $('#clave').val('');
    $("#usuario").focus();
}

function registro() {
    var usuario = $('#usuario').val();
    var clave = $('#clave').val();
    var parametros = {
        "name" : usuario,
        "pass" : clave
    };
    var $envio = $.ajax({
        url: 'login/registro.php',
        data: parametros,
        type: 'POST',
        dataType: 'json'
    });

    $envio.success(function(data){
        if (data.estado == "P") {
            AlertToast('Tu solicitud de ingreso todavía no ha sido aprobada.','clear','red');
            clear();
        } 
        else if (data.estado == "A") {
           AlertToast('Tu usuario ya esta registrado en el sistema.','done','green');
        } 
        else if (data.registrado == "OK") {
            AlertToast('¡Estás ingresando por primera vez! Espera a que el administrador acepte la solicitud de ingreso.','done','green');
            clear();
        } 
        else if (data.registrado == "FAIL") {
            AlertToast('Usuario o clave incorrecta. Vuelve a digitarlos por favor.','clear','red');
            clear();
        }
    });
}

function login() {
    var usuario = $('#usuario').val();
    var clave = $('#clave').val();
    var parametros = {
        "name" : usuario,
        "pass" : clave
    };
    var $envio = $.ajax({
        url: 'login/control.php',
        data: parametros,
        type: 'POST',
        dataType: 'json'
    });

    $envio.success(function(data){
        if (data.ingreso == "FAIL") {
            AlertToast('Usuario o clave incorrecta. Vuelve a digitarlos por favor.','clear','red');
            clear();
        }         
        else if (data.rol == 1 && data.ingreso == "OK") {
            window.location.href='modules/table-admin.php';   
        }
        else if (data.rol != 1 && data.ingreso == "OK") {
            //validar tipos de usuarios de bodegas
            window.location.href='modules/table-admin.php';
        }
        else if (data.ingreso == "PENDIENTE") {
            AlertToast('Tu solicitud de ingreso todavía no ha sido aprobada. Contacta al administrador','clear','red');
            clear();
        }
        else if (data.ingreso == "REGISTRAR") {
            AlertToast('Seleciona "REGISTRAR" para poder enviar una solicitud de acceso al sistema.','clear','red');
        }
    });
}