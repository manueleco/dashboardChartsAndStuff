<!--
Proyecto:CONTROL PLAN DE PRODUCCION
Descripción: 
Autor: Josué Saravia - jsaravia@tata.com.gt
Fecha Inicio: 31-08-2018
-->

<?php 
	//require("../login/seguridad.php");
?>

<!DOCTYPE html>
<html>

<body>

	<?php include("menu_nav.php"); ?>
	
	
	<main>

		<div class="row">
			<div class="col s10 offset-s1">
				<h5>PROMEDIO DE RESPUESTA EN ETAPAS</h5>
			</div>
		</div>

		<div class="row">
			<div class="col s10 offset-s1" id="">
				<div class="divider"></div>
				<table id="TableData" class="table responsive-table striped highlight">
					<thead>
						<tr>
							<th>NO.</th>
							<th>ETAPA</th>
							<th>PROMEDIO DE DIAS</th>
							<th>TOTAL ACTUALIZADOS</th>
							<th>MOVIMIENTO</th>
							<th>SEMANA</th>
							<th>MES ACTUALIZACION</th>
						</tr>
					</thead>
					<tbody>
						<?php require('../database/conn.php');

						//header('Content-Type: text/html; charset=UTF-8');
						mysqli_set_charset($mysqli, "utf8");

						$query = mysqli_query($mysqli, "SELECT L.ETAPA, CONCAT(ROUND(AVG(DATEDIFF(L.FEC_INICIOPROD, L.FEC_CAMBIO)),0), ' DIAS') AS PROMEDIO_DIAS, COUNT(IDPLAN) TOTAL_ACTUALIZADOS, CASE
														WHEN L.CAMBIO_ESTADO = 'N - P' THEN 'Incompleto a Despachado'
														WHEN L.CAMBIO_ESTADO = 'P - Y' THEN 'Despachado a Confirmado'
														WHEN L.CAMBIO_ESTADO = 'Y - N' THEN 'Confirmado a Incompleto'
														END AS CAMBIO_ESTADO,
														WEEK(FEC_INICIOPROD,1) AS SEMANA,
														CASE 
														WHEN MONTH(L.FEC_CAMBIO) = '1' THEN 'ENERO ' 
														WHEN MONTH(L.FEC_CAMBIO) = '2' THEN 'FEBREBRO ' 
														WHEN MONTH(L.FEC_CAMBIO) = '3' THEN 'MARZO ' 
														WHEN MONTH(L.FEC_CAMBIO) = '4' THEN 'ABRIL ' 
														WHEN MONTH(L.FEC_CAMBIO) = '5' THEN 'MAYO ' 
														WHEN MONTH(L.FEC_CAMBIO) = '6' THEN 'JUNIO ' 
														WHEN MONTH(L.FEC_CAMBIO) = '7' THEN 'JULIO ' 
														WHEN MONTH(L.FEC_CAMBIO) = '8' THEN 'AGOSTO ' 
														WHEN MONTH(L.FEC_CAMBIO) = '9' THEN 'SEPTIEMBRE ' 
														WHEN MONTH(L.FEC_CAMBIO) = '10' THEN 'OCTUBRE ' 
														WHEN MONTH(L.FEC_CAMBIO) = '11' THEN 'NOVIEMBRE ' 
														WHEN MONTH(L.FEC_CAMBIO) = '12' THEN 'DICIEMBRE ' 
														END AS MES

														FROM PP_LOG L
														GROUP BY L.ETAPA, L.CAMBIO_ESTADO, SEMANA, MES;") 
						or die('error: '.mysqli_error($mysqli));
						
						$i = 1;
						while ($strData = mysqli_fetch_assoc($query)) {	?>
							<tr>
								<td><?php print $i ?></td>
								<td><?php print $strData["ETAPA"]; ?></td>
								<td><?php print $strData["PROMEDIO_DIAS"]; ?></td>
								<td><?php print $strData["TOTAL_ACTUALIZADOS"]; ?></td>
								<td><?php print $strData["CAMBIO_ESTADO"]; ?></td>
								<td><?php print $strData["SEMANA"]; ?></td>
								<td><?php print $strData["MES"]; ?></td>
							</tr>
							<?php $i+=1; ?>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>

	</main>

	<script src="../js/jquery-2.1.1.min.js"></script><!--Import jQuery before materialize.js-->
	<script src="../js/materialize.min.js"></script><!-- Importar funciones de materialize css -->
	<script src="../js/jquery.dataTables.min.js"></script><!-- pluggin de jquery para hacer tablas dinámicas -->
	<script src="../js/admin_usuarios.js"></script>
	<script src="../js/materializeEffects.js"></script><!-- Funciones de jquery que necesita materializecss -->

	<script type="text/javascript">

		$(document).on("ready", function(){
			mostrarData();
		});


		var mostrarData = function(){
			var table = $('#TableData').DataTable({
				"destroy":true,
				"bPaginate": true,
				"bSort": true,
		        "bJQueryUI": false,
		        "lengthMenu": [[5, 8, 10, 20, 25, 50, -1], [5, 8, 10, 20, 25, 50, "Todos"]],
		        "iDisplayLength": -1,
		        "bProcessing": false,
		        "language": {
		        	"sProcessing":     '<div class="progress"><div class="indeterminate"></div></div>',
		        	"sLengthMenu":     "Mostrar _MENU_ <br>",
		        	"sZeroRecords":    "No se encontraron datos",
		        	"sEmptyTable":     "Ningún dato disponible en esta tabla",
		        	"sInfo":           "Mostrando datos del _START_ al _END_ de un total de _TOTAL_",
		        	"sInfoEmpty":      "Mostrando datos del 0 al 0 de un total de 0",
		        	"sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
		        	"sInfoPostFix":    "",
		        	"sSearch":         "<br>",
		        	"sSearchPlaceholder": " BUSCAR",
		        	"sUrl":            "",
		        	"sInfoThousands":  ",",
		        	"sLoadingRecords": '<div class="progress"><div class="indeterminate"></div></div>',
		        	"oPaginate": {
		        		"sFirst":    "Primero",
		        		"sLast":     "Último",
		        		"sNext":     "Siguiente",
		        		"sPrevious": "Anterior"
		        	}
		        }
		    });
			$('select').addClass("browser-default");
		}
	</script>

</body>
</html>