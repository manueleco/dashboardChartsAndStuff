<!DOCTYPE html>
<html>

<body>

	<?php include("menu_nav.php"); ?>

	<div class="container">
		<h3>Página de ayuda</h3>
		<p>El manual de uso esta en construcción</p>
	</div>

	



</body>
</html>