<!--
Proyecto:CONTROL PLAN DE PRODUCCION
Descripción: 
Autor: Josué Saravia - jsaravia@tata.com.gt
Fecha Inicio: 31-08-2018
-->

<?php

//require("../login/seguridad.php");
require('funcs/table_function.php');
include("menu_nav.php");

$userRol = 1;//$_SESSION["RolUser"];
$userSes = 'msaravia'; //$_SESSION["iduser"];

$tablero = $_GET["tablero"];

if (empty($tablero)) {
	echo '<div class="container"><br>			
			<ul class="collapsible">
			   <li>
			      <div class="collapsible-header"><i class="material-icons">event_note</i>Selecciona un tablero de control</div>
			      <div class="collapsible-body"><span>Selecciona uno de los tableros, Control - Corte para ver la información de las órdenes planeadas para las líneas y etapas de corte. Control - Ensmable para ver la información de las órdenes planeadas para las líneas y etapas de Ensmable.</span></div>
			    </li>
			</ul>				
		</div>';
}

else { //Este else cierra al final del contenido para mostrar contenido según tablero

	if ($tablero == 1) {
		//echo '<p>&nbsp;&nbsp;<b>CORTE</b></p>';
		$tabEtapa = "CORTE";
	} else if ($tablero == 2) {
		//echo '<p>&nbsp;&nbsp;<b>ENSAMBLE</b></p>';
		$tabEtapa = "ENSAMBLE";
	}

//contenido...

?>

<!DOCTYPE html>
<html lang="es">

<style type="text/css">
	@media only screen and (min-width: 600px) {
		#linDate {
			margin-left: 75px;
		}
	}
	@media only screen and (max-width: 600px) {
		#linDate {
			margin-left: 10px;
			width: 300px;
		}
	}

	.cent {
		text-align: center;
	}

	td {
		width: 10px;
		height: 10px;
	}
</style>

<body>

	<div class="row">
	</div>

	<main class="control">
		<!-- FORMULARIO SEGUN TABLERO -->
		<?php 
		if ($tablero == 1) {
			echo '<form autocomplete="off" action="'.$_SERVER['PHP_SELF']."?&tablero=1".'" method="POST">';
		} else if ($tablero == 2) {
			echo '<form autocomplete="off" action="'.$_SERVER['PHP_SELF']."?&tablero=2".'" method="POST">';
		}

		?>

		<!-- <form autocomplete="off" action="<?php // echo $_SERVER['PHP_SELF'] ?>" method="POST"> -->
			<div class="left-align">
				<div class="col s12 m12">
					<div class="row" id="linDate">

						<div id="etapaDiv">
							<select id="selectEtapa" name="selectEtapa" class="col s12 m2" style="margin-right: 50px;">
								<option disabled="disabled" value="0">ETAPA</option>
								<?php
								if ($tablero == 1) {
									echo '<option selected="selected" value="CORTE">CORTE</option>';
								} else if ($tablero == 2) {
									echo '<option selected="selected" value="ENSAMBLE">ENSAMBLE</option>';										
								}
								?>
								<!-- <option value="LAMINADO">LAMINADO</option> -->
							</select>
						</div> 

						<select id="selectLinea" name="selectLinea" class="col s12 m2" style="margin-right: 50px;" onchange="OcultaEtapa();">
							<option selected="selected" disabled="disabled" value="0">LINEA/AREA</option>
							<?php
							require("../database/conn.php");
							mysqli_set_charset($mysqli, "utf8");
							$strQuery = mysqli_query($mysqli, "SELECT LINEA, DESCRIPCION FROM LINEAS_MAESTRO WHERE DESCRIPCION LIKE '%$tabEtapa%';") or die('Error LINEAS_MAESTRO DWH: '.mysqli_error($mysqli));
							while($row = $strQuery->fetch_array(MYSQLI_ASSOC)){ ?>
								<option value="<?php echo $row["DESCRIPCION"]; ?>"><?php echo $row["LINEA"]." - ".$row["DESCRIPCION"]; ?></option>
							<?php }
							$mysqli->close();
							?>
						</select>

						<select id="selectSemana" name="selectSemana" class="col s12 m2" style="margin-right: 50px;" onchange="OcultaFecha();">
							<option selected="selected" disabled="disabled" value="0">SEMANA</option>
							<?php
							require("../database/conn.php");
							mysqli_set_charset($mysqli, "utf8");
							$strQuery = mysqli_query($mysqli, "SELECT WEEK(S.INICIOPROD,1) SEMANA_INPROD FROM PP_SEMANAL S GROUP BY SEMANA_INPROD ORDER BY INICIOPROD DESC;") or die('Error SEMANA_INPROD DWH: '.mysqli_error($mysqli));
							while($row = $strQuery->fetch_array(MYSQLI_ASSOC)){ ?>
								<option value="<?php echo $row["SEMANA_INPROD"]; ?>"><?php echo " SEMANA ".$row["SEMANA_INPROD"]; ?></option>
							<?php }
							$mysqli->close();
							?>
						</select>

						<div id="fechaDiv">
							<?php
							require("../database/conn.php");
							$strQuery = mysqli_query($mysqli, "SELECT MIN(ACTUALIZACION) AS MIN_FEC FROM PP_SEMANAL;") or die('Error MIN_FECHA DWH: '.mysqli_error($mysqli));
							while($row = $strQuery->fetch_array(MYSQLI_ASSOC)){
								$min_fec = $row["MIN_FEC"];
							}
							$mysqli->close();
							?>
							<input class="col s12 m2" type="date" name="fecha" id="fecha" style="margin-right: 50px;" min="<?php echo $min_fec; ?>">
						</div>
						
					</div>
					<div class="row">
						<div style="margin-left: 5%;">
							<button type="submit" class="btn grey col s8 m3"><b>Consultar</b></button>
						</div>
					</div>
				</div>
			</div>	
		</form>

		<div class="left-align" style="margin-left: 75px;" id="control-panel">
			<p>
				<?php 
				require("../database/conn.php");
				mysqli_set_charset($mysqli, "utf8");

				$queryCols = mysqli_query($mysqli, "SELECT ROLNOMBRE FROM PP_ROL WHERE ACTIVO = 'Y' AND ID = $userRol;") 
				or die('Error table-admin 1: '.mysqli_error($mysqli));
				
				while ($strData = mysqli_fetch_assoc($queryCols)) {
					echo '<p class="left-align">Rol de usuario: '.$rol = $strData["ROLNOMBRE"].'</p>';
				}
				?>
			</p>

			<label>
				<input type="checkbox" />
				<span>En proceso</span>
			</label>&nbsp;&nbsp;&nbsp;
			<label>
				<input type="checkbox" checked="checked" />
				<span>Despachado</span>
			</label>&nbsp;&nbsp;&nbsp;
			<label>
				<input type="checkbox" class="filled-in" checked="checked" />
				<span>Recibido</span>
			</label>&nbsp;&nbsp;&nbsp;

		</div>

		<div class="row">
			<div class="col s11" id="table">
				<br><div class="divider"></div>

				<?php
				//CONEXION
				require("../database/conn.php");
				mysqli_set_charset($mysqli, "utf8");

				//VALIDO QUE AL MENOS UN FILTRO TRAIGA DATA
				if (!empty($_POST["selectLinea"]) || !empty($_POST["selectEtapa"]) || !empty($_POST["fecha"]) || !empty($_POST["selectSemana"])) {

					$linea = $_POST["selectLinea"];
					$etapa = $_POST["selectEtapa"];
					$fec = $_POST["fecha"];
					$semana = $_POST["selectSemana"];
					
					echo "<label><br><b>ETAPA:</b> - ".$etapa."</label>";
					echo "<label><br><b>LINEA:</b> - ".$linea."</label>";
					echo "<label><br><b>SEMANA:</b> - ".$semana."</label>";
					echo "<label><br><b>FECHA:</b> - ".$fec."</label>";
					
					//CALCULO SEMANA ACTUAL
					$querySemAct = mysqli_query($mysqli, "SELECT WEEK(CURDATE(),1) SEMANA_ACTUAL FROM PP_SEMANAL LIMIT 1;")
					or die('Error Semana actual: '.mysqli_error($mysqli));
					while ($strData = mysqli_fetch_assoc($querySemAct)) {
						$semAct = $strData["SEMANA_ACTUAL"];
					}

					//$semAct = 39;
					if (empty($semana)) {
						$semana = $semAct;
					}

					if (!empty($fec)) {
						//CALCULO SEMANA SEGUN INICIO DE PRODUCCION
						$querySemIni = mysqli_query($mysqli, "SELECT WEEK(INICIOPROD,1) SEMANA_INPROD FROM PP_SEMANAL WHERE INICIOPROD = '$fec;' LIMIT 1;")
						or die('Error Semana inProd: '.mysqli_error($mysqli));
						while ($strData = mysqli_fetch_assoc($querySemIni)) {
							$semIni = $strData["SEMANA_INPROD"];
						}
						$semana = "0";
					}
					
					//OPERACIONES PARA VISUALIZACION Y PRIVILEGIOS DE USUARIOS
					$queryPrivs = mysqli_query($mysqli, "SELECT * FROM PP_PRIVILEGIO WHERE ROLUSER = $userRol;") 
					or die('Error table-admin 2: '.mysqli_error($mysqli));
					while ($row = mysqli_fetch_assoc($queryPrivs)) {
						$columnas = strtoupper( $row["COLUMNAS"] );

						if ($semana == $semAct || $semIni == $semAct) {
							$permiso = $row["PERMISOEDICION"];
						} else {
							$permiso = 1;
							echo '<p class="LEFT"><b style="color:red;">NOTA:</b> Los checks de las semanas diferentes a la actual no pueden actualizarse.</p>';
						}

						//Estas columnas se mostrarán siempre en ambos tableros
						$colsDefault = "IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN,";

						
						//***************************************************
						//VALIDACION PARA SEPARAR TABLEROS (CORTE, ENSAMBLE)
						//***************************************************
						if ($tablero == 1) {
							//En corte, se muestra únicamente la parte de cuero en este caso FAJAS
							$columnas = "MATERIAL";
						}

						if($columnas != "*") {
							//Cuando solo uno de los campos esta vacio
							if (!empty($linea) && !empty($fec) && !empty($etapa) && !empty($semana)) {
								$consulta = "SELECT ".$colsDefault.$columnas."  FROM PP_SEMANAL WHERE DESCLINEA LIKE '%$linea%' AND ETAPA = '$etapa' AND INICIOPROD = '$fec' AND WEEK(INICIOPROD,1) = '$semana';";
							}
							else if (!empty($linea) && !empty($etapa) && !empty($semana) && empty($fec)) {
								$consulta = "SELECT ".$colsDefault.$columnas."  FROM PP_SEMANAL WHERE DESCLINEA LIKE '%$linea%' AND ETAPA = '$etapa' AND WEEK(INICIOPROD,1) = '$semana';";
							}
							else if (!empty($linea) && !empty($fec) && !empty($semana) && empty($etapa)) {
								$consulta = "SELECT ".$colsDefault.$columnas."  FROM PP_SEMANAL WHERE DESCLINEA LIKE '%$linea%' AND INICIOPROD = '$fec' AND WEEK(INICIOPROD,1) = '$semana';";
							}
							else if (!empty($fec) && !empty($etapa) && !empty($semana) && empty($linea)) {
								$consulta = "SELECT ".$colsDefault.$columnas."  FROM PP_SEMANAL WHERE ETAPA = '$etapa' AND INICIOPROD = '$fec' AND WEEK(INICIOPROD,1) = '$semana' AND DESCLINEA LIKE '%$tabEtapa%';";
							}
							else if (!empty($fec) && !empty($etapa) && !empty($linea) && empty($semana)) {
								$consulta = "SELECT ".$colsDefault.$columnas." , RODILLOSPKS, TROQUELES, CLISHES, HEBILLAS, HANGERS, PASADORES, TICKETS FROM PP_SEMANAL WHERE ETAPA = '$etapa' AND INICIOPROD = '$fec' AND DESCLINEA LIKE '%$linea%';";
							}

							//Cuando dos campos estan vacios, validacion segun etapa seleccionada
							if (!empty($etapa) && !empty($linea) && empty($semana) && empty($fec)) {
								$consulta = "SELECT ".$colsDefault.$columnas."  FROM PP_SEMANAL WHERE DESCLINEA LIKE '%$linea%' AND ETAPA = '$etapa';";
							}
							else if (!empty($etapa) && !empty($semana) && empty($linea) && empty($fec)) {
								$consulta = "SELECT ".$colsDefault.$columnas."  FROM PP_SEMANAL WHERE ETAPA = '$etapa' AND WEEK(INICIOPROD,1) = '$semana';";
								//echo "------------HOLA SOY ETAPA-------".$etapa;
							}
							else if (!empty($etapa) && !empty($fec) && empty($linea) && empty($semana)) {
								$consulta = "SELECT ".$colsDefault.$columnas."  FROM PP_SEMANAL WHERE ETAPA = '$etapa'  AND INICIOPROD = '$fec';";
							}

							//Validacion consulta, según linea seleccionada
							else if (!empty($linea) && !empty($semana) && empty($etapa) && empty($fec)) {
								$consulta = "SELECT ".$colsDefault.$columnas."  FROM PP_SEMANAL WHERE DESCLINEA LIKE '%$linea%' AND WEEK(INICIOPROD,1) = '$semana';";
							}
							else if (!empty($linea) && !empty($fec) && empty($etapa) && empty($semana)) {
								$consulta = "SELECT ".$colsDefault.$columnas."  FROM PP_SEMANAL WHERE DESCLINEA LIKE '%$linea%' AND INICIOPROD = '$fec';";
							}

							//Validacion consulta según semana seleccionada
							else if (!empty($semana) && !empty($fec) && empty($etapa) && empty($linea)) {
								$consulta = "SELECT ".$colsDefault.$columnas."  FROM PP_SEMANAL WHERE WEEK(INICIOPROD,1) = '$semana' AND INICIOPROD = '$fec';";
							}

							else if (empty($linea) || empty($fec) || empty($etapa) || empty($semana)) {
								if (empty($linea)) {
									$linea = '0';
								}
								if (empty($etapa)) {
									$etapa = '-';
								}
								if (empty($fec)) {
									$fec = '0000-00-00';
								}
								if (empty($semana)) {
									$semana = '0';
								}
								$consulta = "SELECT ".$colsDefault.$columnas."  FROM PP_SEMANAL WHERE DESCLINEA LIKE '$linea' OR ETAPA = '$etapa' OR INICIOPROD = '$fec' OR WEEK(INICIOPROD,1) = '$semana' AND DESCLINEA LIKE '%tabEtapa%';";
							}
							//echo $consulta;
							$columnas = str_replace(",", "','", $columnas);
							$columnas = "'".str_replace(" ", "", $columnas)."'";

							$numsCols = mysqli_query($mysqli, "SELECT ORDINAL_POSITION AS num_col, COLUMN_NAME AS nom_col FROM INFORMATION_SCHEMA.COLUMNS  WHERE TABLE_NAME = 'PP_SEMANAL' AND COLUMN_NAME IN ($columnas)") 
							or die('Error table-admin 3: '.mysqli_error($mysqli));
							
							while ($strData = mysqli_fetch_assoc($numsCols)) {
								$cols[] = array('columna' => $strData["nom_col"]);
							}

							BuildTable($consulta, $cols, $permiso);
						}

						echo '<input id="hid_query" type="hidden" name="hid_query" value="'.$consulta.'">'; //Se envía por ajax a process_plan.php para hacer operación al dar click en cada casilla

					}
				}
				
				mysqli_close($mysqli);

			} //Fin de contenido según tablero, cierre del else.

			?>

		</div>
	</div>
</main>

<!-- Modal para el detalle del estilo para mostrar información como troquel -->
<div id="info_estilo" class="modal" style="max-width: 60%;">
	<div class="modal-content">
		<div id="contentModal">
		</div>
	</div>
	<div class="modal-footer">
		<a class="modal-action modal-close waves-effect waves-green btn-flat">ok</a>
	</div>
</div>

<script src="../js/jquery-2.1.1.min.js"></script><!--Importar jQuery antes de materialize.js-->
<script src="../js/materialize.min.js"></script><!-- Importar funciones de materialize css -->
<script src="../js/jquery.dataTables.min.js"></script><!-- pluggin de jquery para hacer tablas dinámicas -->
<script src="../js/materializeEffects.js"></script><!-- Funciones de jquery que necesita materializecss para dinamismo -->
<script>

	$(document).on("ready", function(){
		mostrarData();
	});

	var mostrarData = function(){
		var table = $('#TableData').DataTable({
			"destroy":true,
			"bPaginate": true,
			"bSort": true,
			"bJQueryUI": false,
			"lengthMenu": [[5, 8, 10, 15, 20, 25, 50, -1], [5, 8, 10, 15, 20, 25, 50, "Todos"]],
			"iDisplayLength": 10,
			"bProcessing": false,
			"language": {
				"sProcessing":     '<div class="progress"><div class="indeterminate"></div></div>',
				"sLengthMenu":     "&nbsp; Mostrar _MENU_ <br>",
				"sZeroRecords":    "No se encontraron datos",
				"sEmptyTable":     "Ningún dato disponible en esta tabla",
				"sInfo":           "Mostrando datos del _START_ al _END_ de un total de _TOTAL_",
				"sInfoEmpty":      "Mostrando datos del 0 al 0 de un total de 0",
				"sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
				"sInfoPostFix":    "",
				"sSearch":         "<br>",
				"sSearchPlaceholder": " BUSCAR EN EL PLAN",
				"sUrl":            "",
				"sInfoThousands":  ",",
				"sLoadingRecords": '<div class="progress"><div class="indeterminate"></div></div>',
				"oPaginate": {
					"sFirst":    "Primero",
					"sLast":     "Último",
					"sNext":     "Siguiente",
					"sPrevious": "Anterior"
				}
			}
		});
		$('select').addClass("browser-default");
	}

	function AlertToast(message,icon,color){
		var toastHTML = '<span>'+message+'&nbsp;</span><i class="material-icons'+' '+color+'-text'+'">'+icon+'</i>';
		return M.toast({html: toastHTML, classes: 'rounded'});
	}

	function checkSave(id,check,columna){
		var query = document.getElementById("hid_query").value;
		var parametros = {
			"id" : id,
			"etapa" : columna,
			"op" : check,
			"query" : query
		};

		var $envio = $.ajax({
			url: '../database/process_plan.php',
			data: parametros,
			type: 'POST',
		});

		$envio.success(function(){
			location.reload();
			/*$("#TableData").load(" #TableData");
			mostrarData();*/

		});
	}

	function OcultaFecha(){
		document.getElementById("fecha").disabled = true;
	}

	function OcultaEtapa(){
		document.getElementById("selectEtapa").disabled = true;
	}

	/*
	//Función se usará al querer mostrar datos detalle de troqueles
	//que se extraeran de hoja técnica.
	function detalle(idPlan){
		console.log(idPlan);

		var parametros = {
			"id" : idPlan
		};

		var $envio = $.ajax({
			url: '../database/process_detalle.php',
			data: parametros,
			type: 'POST',
			dataType: 'json'
		});

		$envio.success(function(data){
			document.getElementById("contentModal").innerHTML="";
			var contenido =
			"<p><b>DETALLE DE ACCESORIOS</b></p>"+
			"<p>Orden: "+data.ordendesc+"</p>"+
			"<p>Estilo: "+data.estilo+"</p>"+
			"<table>"+
			"<thead>"
			+"<th>Fajas</th>"
			+"<th>RodillosPKS</th>"
			+"<th>Troqueles</th>"
			+"<th>Clishes</th>"
			+"<th>Hebillas</th>"
			+"<th>Hangers</th>"
			+"<th>Pasadores</th>"
			+"<th>Tickets</th>"
			+"</thead>"

			+'<tbody class="table responsive-table striped highlight" style="font-size: 12px;">'
			+"<td>Fajas</td>"
			+"<td>RodillosPKS</td>"
			+"<td>Troqueles</td>"
			+"<td>Clishes</td>"
			+"<td>Hebillas</td>"
			+"<td>Hangers</td>"
			+"<td>Pasadores</td>"
			+"<td>Tickets</td>"
			+"</tbody>"

			+"</table>"

			$(contenido).appendTo("#contentModal");
		});
	}*/

</script>
</body>
</html>

