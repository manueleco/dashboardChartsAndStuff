<!DOCTYPE html>
<html>

<body>

	<?php include("menu_nav.php"); ?>

	<div class="container">
		<div id="wrapper">
			<br>
			<p>Notificaciones con PUSH JS</p>
			<button class="btn" id="notify-button">Notificarme</button>
		</div>	
	</div>

	

	<script type="text/javascript">
		$("#notify-button").click(function(){
			//Push.create("Hola mundo");
			

			Push.create("Despacho pendiente para Línea Ensamble 1", {
			    body: "Troqueles y clishes pendientes de despachar para el día de hoy.",
			    icon: '../images/logo/calendar1.png',
			    timeout: 10000,
			    onClick: function () {
			    	//location.reload("http://localhost/DevsJosue/Proyecto_planprod/index2.php");
			    	window.location="http://localhost/DevsJosue/Proyecto_planprod/index2.php";
			        window.focus();
			        this.close();
			    }
			});


		});
	</script>



</body>
</html>