<!--
Proyecto:CONTROL PLAN DE PRODUCCION
Descripción: 
Autor: Josué Saravia - jsaravia@tata.com.gt
Fecha Inicio: 31-08-2018
-->

<?php 
	//require("../login/seguridad.php");
	$userRol = 1; //$_SESSION["RolUser"];
	$usrName = 'msaravia'; //$_SESSION["nombreAD"];
	//$usrMail = $_SESSION["correoAD"];
	
	$tablero = $_GET["tablero"];
	
?>

<!DOCTYPE html>
<html>

<head>
	<link type="text/css" rel="stylesheet" href="../materialize/css/icons/icons.css"><!--Import Google Icon Font-->
	<link rel="stylesheet" href="../materialize/css/materialize.min.css"><!--Import materialize.css-->
	<link rel="stylesheet" href="../js/jquery.dataTables.min.css"><!-- Pluggin de jquery para tablas dinamicas  dataTables-->
	<link rel="stylesheet" type="text/css" href="../materialize/css/estilos.css"><!-- Estilos personalizados -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/><!--Let browser know website is optimized for mobile-->
	<meta charset="utf-8"><!-- Codificación para español -->
	<title>PLAN DE PRODUCCION</title>
    <link rel="icon" href="../images/logo/calendar1.png" sizes="30x30">
</head>
	
<body>
	<header>

		<?php 
		//USUARIO ADMINISTRADOR
		if ($userRol == 1) { ?>

			<!-- <a href="#" data-target="slide-out" class="sidenav-trigger btn-floating grey hoverable" style="position: absolute; margin-top: 12px; margin-left: 5px; z-index: 1;"><i class="material-icons">menu</i></a> -->

			<div class="navbar-fixed">
			  <nav class="grey darken-1">
			    <div class="nav-wrapper">
			    	
			      <a href="table-admin.php" class="brand-logo">&nbsp;TATA</a>
			      <a href="" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
			      <ul class="right hide-on-med-and-down">

			      	<?php if ($tablero == 1) { ?>
			      		<li class="active"><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>	
			      		<li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
			      	<?php } else if($tablero == 2) { ?>
			      		<li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
			      		<li class="active"><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
			      	<?php } else { ?>
			        <li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
			        <li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
			        <?php } ?>

			        <li><a href="reporte_tiempo.php?tablero=3"><i class="material-icons left white-text">book</i>Informe</a></li>
			        <li><a href="admin_areas.php?tablero=4"><i class="material-icons left white-text">donut_large</i>Etapas</a></li>
			        <li><a href="admin_usuarios.php?tablero=5"><i class="material-icons left white-text">person</i>Usuarios</a></li>
			        <li class="tooltipped" data-position="left" data-tooltip="Notificaciones"><a href="notificaciones.php"><i class="material-icons center white-text">notifications</i></a></li>
			        <li class="tooltipped" data-position="left" data-tooltip="Ayuda"><a href="ayuda.php"><i class="material-icons center white-text">help</i></a></li>
			        <li><a class="material-icons white-text modal-trigger tooltipped" data-position="left" data-tooltip="Salir" href="#mod_salir"><i class="material-icons">power_settings_new</i></a></li>
			      </ul>
			    </div>
			  </nav>
		  	</div>

		    <ul class="sidenav" id="mobile-demo">

		       <?php if ($tablero == 1) { ?>
		      		<li class="active"><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>	
		      		<li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
		      	<?php } else if($tablero == 2) { ?>
		      		<li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
		      		<li class="active"><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
		      	<?php } else { ?>
		        <li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
		        <li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li> -->
		        <?php } ?>

			   <li><a href="reporte_tiempo.php?tablero=3"><i class="material-icons left black-text">book</i>Informe</a></li>
			   <li><a href="admin_areas.php?tablero=4"><i class="material-icons left black-text">donut_large</i>Etapas</a></li>
			   <li><a href="admin_roles.php"><i class="material-icons left black-text">lock</i>Permisos</a></li>
			   <li><a href="admin_usuarios.php?tablero=5"><i class="material-icons left black-text">person</i>Usuarios</a></li>
			   <li><a href="notificaciones.php"><i class="material-icons center red-text">notifications</i></a></li>
			   <!-- <li><a href="ayuda.php"><i class="material-icons center red-text">help</i></a></li> -->
			   <li><a class="material-icons white-text modal-trigger" href="#mod_salir"><i class="material-icons">power_settings_new</i></a></li>
		    </ul>

		<?php } 

		//USUARIO PLANIFICACION
		else if ($userRol == 2) { ?>

			<div class="navbar-fixed">
			  <nav class="grey darken-2" style="">
			    <div class="nav-wrapper">
			      <a href="table-admin.php" class="brand-logo">TATA</a>
			      <a href="" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
			      <ul class="right hide-on-med-and-down">
			        
			        <?php if ($tablero == 1) { ?>
			      		<li class="active"><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>	
			      		<li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
			      	<?php } else if($tablero == 2) { ?>
			      		<li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
			      		<li class="active"><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
			      	<?php } else { ?>
			        <li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
			        <li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
			        <?php } ?>

			        <li><a href="reporte_tiempo.php?tablero=3"><i class="material-icons left white-text">book</i>Informe</a></li>
			        <!-- <li class="tooltipped" data-position="left" data-tooltip="Ayuda"><a href="ayuda.php"><i class="material-icons center white-text">help</i></a></li> -->
			        <li><a class="material-icons white-text modal-trigger tooltipped" data-position="left" data-tooltip="Salir" href="#mod_salir"><i class="material-icons">power_settings_new</i></a></li>
			      </ul>
			    </div>
			  </nav>
		  	</div>

		    <ul class="sidenav" id="mobile-demo">
			   	
			   <?php if ($tablero == 1) { ?>
		      		<li class="active"><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>	
		      		<li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
		      	<?php } else if($tablero == 2) { ?>
		      		<li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
		      		<li class="active"><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
		      	<?php } else { ?>
		        <li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
		        <li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
		        <?php } ?>

			   <li><a href="reporte_tiempo.php?tablero=3"><i class="material-icons left black-text">book</i>Informe</a></li>
			   <!-- <li><a href="ayuda.php"><i class="material-icons center red-text">help</i></a></li> -->
			   <li><a class="material-icons white-text modal-trigger" href="#mod_salir"><i class="material-icons">power_settings_new</i></a></li>
		    </ul>

		<?php }

		//USUARIO GERENTE DE PRODUCCION
		else if ($userRol == 3) { ?>

			<div class="navbar-fixed">
			  <nav class="grey darken-2" style="">
			    <div class="nav-wrapper">
			      <a href="table-admin.php" class="brand-logo">TATA</a>
			      <a href="" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
			      <ul class="right hide-on-med-and-down">
			        
			        <?php if ($tablero == 1) { ?>
			      		<li class="active"><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>	
			      		<li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
			      	<?php } else if($tablero == 2) { ?>
			      		<li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
			      		<li class="active"><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
			      	<?php } else { ?>
			        <li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
			        <li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
			        <?php } ?>

			        <li><a href="reporte_tiempo.php?tablero=3"><i class="material-icons left white-text">book</i>Informe</a></li>
			        <!-- <li class="tooltipped" data-position="left" data-tooltip="Ayuda"><a href="ayuda.php"><i class="material-icons center white-text">help</i></a></li> -->
			        <li><a class="material-icons white-text modal-trigger tooltipped" data-position="left" data-tooltip="Salir" href="#mod_salir"><i class="material-icons">power_settings_new</i></a></li>
			      </ul>
			    </div>
			  </nav>
		  	</div>

		    <ul class="sidenav" id="mobile-demo">
			   
		    	<?php if ($tablero == 1) { ?>
		      		<li class="active"><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>	
		      		<li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
		      	<?php } else if($tablero == 2) { ?>
		      		<li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
		      		<li class="active"><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
		      	<?php } else { ?>
		        <li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
		        <li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
		        <?php } ?>

			   <li><a href="reporte_tiempo.php?tablero=3"><i class="material-icons left black-text">book</i>Informe</a></li>
			   <!-- <li><a href="ayuda.php"><i class="material-icons center red-text">help</i></a></li> -->
			   <li><a class="material-icons white-text modal-trigger" href="#mod_salir"><i class="material-icons">power_settings_new</i></a></li>
		    </ul>

		<?php } 

		//USUARIO JEFE DE LINEA
		else if ($userRol == 4) { ?>

			<div class="navbar-fixed">
			  <nav class="grey darken-2" style="">
			    <div class="nav-wrapper">
			      <a href="table-admin.php" class="brand-logo">TATA</a>
			      <a href="" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
			      <ul class="right hide-on-med-and-down">
			        
			      	<?php if ($tablero == 1) { ?>
			      		<li class="active"><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>	
			      		<li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
			      	<?php } else if($tablero == 2) { ?>
			      		<li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
			      		<li class="active"><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
			      	<?php } else { ?>
			        <li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
			        <li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
			        <?php } ?>

			        <!-- <li class="tooltipped" data-position="left" data-tooltip="Ayuda"><a href="ayuda.php"><i class="material-icons center white-text">help</i></a></li> -->
			        <li><a class="material-icons white-text modal-trigger tooltipped" data-position="left" data-tooltip="Salir" href="#mod_salir"><i class="material-icons">power_settings_new</i></a></li>
			      </ul>
			    </div>
			  </nav>
		  	</div>

		    <ul class="sidenav" id="mobile-demo">
			   
			   <?php if ($tablero == 1) { ?>
		      		<li class="active"><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>	
		      		<li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
		      	<?php } else if($tablero == 2) { ?>
		      		<li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
		      		<li class="active"><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
		      	<?php } else { ?>
		        <li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
		        <li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
		        <?php } ?>

			   <!-- <li><a href="ayuda.php"><i class="material-icons center red-text">help</i></a></li> -->
			   <li><a class="material-icons white-text modal-trigger" href="#mod_salir"><i class="material-icons">power_settings_new</i></a></li>
		    </ul>

		<?php }
		
		//USUARIOS DE BODEGAS
		else { ?>

			<div class="navbar-fixed">
			  <nav class="grey darken-2" style="">
			    <div class="nav-wrapper">
			      <a href="table-admin.php" class="brand-logo">TATA</a>
			      <a href="" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
			      <ul class="right hide-on-med-and-down">
			        
			      	<?php if ($tablero == 1) { ?>
			      		<li class="active"><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>	
			      		<li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
			      	<?php } else if($tablero == 2) { ?>
			      		<li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
			      		<li class="active"><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
			      	<?php } else { ?>
			        <li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
			        <li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
			        <?php } ?>

			        <!-- <li class="tooltipped" data-position="left" data-tooltip="Ayuda"><a href="ayuda.php"><i class="material-icons center white-text">help</i></a></li> -->
			        <li><a class="material-icons white-text modal-trigger tooltipped" data-position="left" data-tooltip="Salir" href="#mod_salir"><i class="material-icons">power_settings_new</i></a></li>
			      </ul>
			    </div>
			  </nav>
		  	</div>

		    <ul class="sidenav" id="mobile-demo">
			   
		    	<?php if ($tablero == 1) { ?>
		      		<li class="active"><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>	
		      		<li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
		      	<?php } else if($tablero == 2) { ?>
		      		<li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
		      		<li class="active"><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>	
		      	<?php } else { ?>
		        <li><a href="table-admin.php?&tablero=1"><i class="material-icons left white-text">event_note</i>Control - Corte</a></li>
		        <li><a href="table-admin.php?&tablero=2"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
		        <?php } ?>

			   <!-- <li><a href="ayuda.php"><i class="material-icons center red-text">help</i></a></li> -->
			   <li><a class="material-icons white-text modal-trigger" href="#mod_salir"><i class="material-icons">power_settings_new</i></a></li>
		    </ul>

		<?php } ?>

	</header>

	<div id="mod_salir" class="modal">
		<div class="modal-content">
			<h4>SALIR</h4>	
			<p>¿Estás seguro de salir de la herramienta?</p>
		</div>
		<div class="modal-footer">
			<a onclick="salir();" class="modal-action modal-close waves-effect waves-white btn-flat blue darken-4 white-text">SALIR</a>
			<a class="modal-action modal-close waves-effect waves-white btn-flat grey white-text">CANCELAR</a>
		</div>
	</div>

	<script type="text/javascript">
		function salir() {
			window.location = "../login/salir.php";
		}
	</script>

	<script src="../js/jquery-2.1.1.min.js"></script><!--Import jQuery before materialize.js-->
	<script src="../js/materialize.min.js"></script><!-- Importar funciones de materialize css -->
	<script src="../js/jquery.dataTables.min.js"></script><!-- pluggin de jquery para hacer tablas dinámicas -->
	<script src="../js/materializeEffects.js"></script><!-- Funciones de jquery que necesita materializecss -->
	<script src="../push.js-master/bin/push.js"></script> <!-- NOTIFICACIONES -->
</body>
</html>