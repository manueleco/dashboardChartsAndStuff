<!--
Proyecto:CONTROL PLAN DE PRODUCCION
Descripción: 
Autor: Josué Saravia - jsaravia@tata.com.gt
Fecha Inicio: 31-08-2018
-->

<?php 
//require("../login/seguridad.php");
	//$user = $_GET["name"];
?>

<!DOCTYPE html>
<html>
<body>
	<?php include("menu_nav.php"); ?>
	<main>
		<div class="row">
		</div>

		<div class="row">
			<!-- FORMULARIO DE ROLES -->
			<div class="col s4 offset-s1">
				<b><p>CREACIÓN DE ROLES</p></b>
				<form autocomplete="off" id="formRol">

					<div class="input-field col s12">
						<input name="rol" id="rol" type="text" maxlength="50">
						<label for="rol">Nombre del nuevo rol</label>
					</div>
					<div>
						<input type="submit" value="Guardar" class="btn col s3 grey left" />
					</div>
					<input type="hidden" name="operacion1" id="operacion1" value="agregar">
					<input type="hidden" name="id" id="id" value="">

				</form>
			</div>
			
			<!-- FORMULARIO DE PRIVILEGIOS -->
			<div class="col s5 offset-s1">
				<b><p>PERMISOS A ROLES</p></b>
				<form autocomplete="off" id="formPriv">

					<div class="input-field col s12">
						<input name="campos" id="campos" type="text" maxlength="50">
						<label for="campos">Campos a visualizar (SEPARADOS POR COMAS)</label>
					</div>

					<!--<div class="input-field col s6">
						<select id="selectColumnas" name="selectColumnas" onchange="agregarCol(this.selectedIndex);">
							<option selected="selected" value="" disabled="">Permiso de edición</option>
							<option value="TICKETS">TICKETS</option>
							<option value="HANGERS">HANGERS</option>
						</select>
					</div>-->

					<div class="input-field col s6">
						
						<?php require('../database/conn.php');
						mysqli_set_charset($mysqli, "utf8");
						$query1 = mysqli_query($mysqli,"SELECT * FROM PP_ROL ORDER BY ID;") or die('error: '.mysqli_error($mysqli)); ?>
						
						<select id="selectRol" name="selectRol" onchange="rolSave(<?php print $row["ID"]; ?>,this.selectedIndex);">
							<option selected="selected" value="" disabled="">Selecciona un rol</option>
							<?php
							while ($raw = mysqli_fetch_assoc($query1)) { ?>
								<option value="<?php print $raw["ID"]; ?>"><?php print $raw["ROLNOMBRE"]; ?></option>
							<?php } ?>
						</select>

					</div>

					<div class="input-field col s6">
						<select id="selectPermiso" name="selectPermiso">
							<option selected="selected" value="" disabled="">Permiso de edición</option>
							<option value="0">0 - IT</option>
							<option value="1">1 - PLANIFICACION/GERENTE-PROD</option>
							<option value="2">2 - AREA/DEP</option>
							<option value="3">3 - JEFE LINEA</option>
						</select>
					</div>

					<div class="input-field">
						<input type="hidden" name="operacion2" id="operacion2" value="agregar">
						<input type="hidden" name="idPrivilegio" id="idPrivilegio" value="">
					</div>

					<div>
						<input type="submit" value="Guardar" class="btn col s2 grey right" />
					</div>

				</form>
			</div>
		</div>

		<div class="col s1"></div>

		<div class="row">
			<div class="col s4 offset-s1" id="">
				<div class="divider"></div>
				<table id="TableData" class="table responsive-table striped highlight">
					<thead>
						<tr>
							<th>No.</th>
							<th>Nombre Rol</th>
							<th>Activo/Inactivo</th>
							<th></th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php require('../database/conn.php');

						header('Content-Type: text/html; charset=UTF-8');
						mysqli_set_charset($mysqli, "utf8");

						$query = mysqli_query($mysqli, "SELECT * FROM PP_ROL;") 
						or die('error: '.mysqli_error($mysqli));
						
						while ($strData = mysqli_fetch_assoc($query)) {	?>
							<tr>
								<td><?php print $strData["ID"]; ?></td>
								<td><?php print $strData["ROLNOMBRE"]; ?></td>
								
								<?php if ($strData["ACTIVO"] == "N") { ?>
									<td><i style="cursor: pointer;" onclick="activarRol(<?php echo $strData["ID"]; ?>)" class="material-icons red-text tooltipped" data-position="right" data-tooltip="¿Activar rol?">lock</i></td>	
								<?php } else  { ?>
									<td><i style="cursor: pointer;" onclick="DesactivarRol(<?php echo $strData["ID"]; ?>)" class="material-icons green-text tooltipped" data-position="right" data-tooltip="¿Desactivar rol?">done</i></td>	
								<?php } ?>

								<td class="tooltipped" data-position="left" data-tooltip="¿Editar nombre del rol?" style="cursor: pointer;" onclick="EditRol(<?php print "'".$strData["ROLNOMBRE"]."'"; ?>,<?php print "'".$strData["ID"]."'"; ?>)"><i class="material-icons grey-text">edit</i></td>
							</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>

			<div class="col s1"></div>

			<div class="col s5" id="">
				<div class="divider"></div>
				<table id="TableData1" class="table responsive-table striped highlight">
					<thead>
						<tr>
							<th>No.</th>
							<th>Rol</th>
							<th>Visibilidad</th>
							<th>Permisos edición</th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php require('../database/conn.php');
						header('Content-Type: text/html; charset=UTF-8');
						mysqli_set_charset($mysqli, "utf8");

						$query = mysqli_query($mysqli, "SELECT P.ID AS IDPRIV, R.ROLNOMBRE, P.COLUMNAS, R.ID AS IDROL, P.PERMISOEDICION
														FROM PP_PRIVILEGIO P
														INNER JOIN PP_ROL R ON R.ID = P.ROLUSER;") 
						or die('error: '.mysqli_error($mysqli));
						
						$i = 1;
						while ($strData = mysqli_fetch_assoc($query)) {	?>
							<tr>
								<td><?php print $strData["IDPRIV"]; ?></td>
								<td><?php print $strData["ROLNOMBRE"]; ?></td>
								<td><?php print $strData["COLUMNAS"]; ?></td>
								<td><?php print $strData["PERMISOEDICION"]; ?></td>
								<td class="tooltipped" data-position="left" data-tooltip="¿Editar columnas visibles?" style="cursor: pointer;" onclick="EditPriv(<?php print "'".$strData["IDPRIV"]."'"; ?>,<?php print "'".$strData["COLUMNAS"]."'"; ?>,<?php print "'".$strData["IDROL"]."'"; ?>,<?php print "'".$strData["PERMISOEDICION"]."'"; ?>)"><i class="material-icons grey-text">edit</i></td>
							</tr>
							<?php $i+=1; ?>
						<?php } ?>
					</tbody>
				</table>
			</div>

		</div>

	</main>

	<script src="../js/jquery-2.1.1.min.js"></script><!--Import jQuery before materialize.js-->
	<script src="../js/materialize.min.js"></script><!-- Importar funciones de materialize css -->
	<script src="../js/jquery.dataTables.min.js"></script><!-- pluggin de jquery para hacer tablas dinámicas -->
	<script src="../js/materializeEffects.js"></script><!-- Funciones de jquery que necesita materializecss -->

	<script type="text/javascript">

		$(document).on("ready", function(){
			$('select').addClass("browser-default");

			$(document).ready(function (e) {

				$("#formRol").on('submit',(function(e) {
					e.preventDefault();
					$.ajax({
						url: "../database/process_rol.php",
						type: "POST",
						data:  new FormData(this),
						contentType: false,
						cache: false,
						processData:false,
						success: function(data)
						{
							AlertToast('Éxito!','done','green');
							$("#rol").focus();
							$("#rol").val('');
							//$("#TableData").load("#table-admin.php #TableData");
							location.reload();
						}
					});
				}));

				$("#formPriv").on('submit',(function(e) {
					e.preventDefault();
					$.ajax({
						url: "../database/process_rol.php",
						type: "POST",
						data:  new FormData(this),
						contentType: false,
						cache: false,
						processData:false,
						success: function(data)
						{
							//AlertToast('Columna agregada con éxito!','done','green');
							location.reload();
						}
					});
				}));
			});
		});

		function AlertToast(message,icon,color){
			var toastHTML = '<span>'+message+'&nbsp;</span><i class="material-icons'+' '+color+'-text'+'">'+icon+'</i>';
			return M.toast({html: toastHTML, classes: 'rounded'});
		}

		function EditRol(rol,id){
			$("#operacion1").val("editar");
			$("#rol").focus();
			$("#rol").val(rol);
			$("#id").val(id);
			console.log(rol+" - "+id);
		}

		function activarRol(id){
    		var parametros = {
    			"id" : id,
    			"operacion1" : "flag",
    			"estado" : "Y"
    		};
    		var $envio = $.ajax({
    			url: '../database/process_rol.php',
    			data: parametros,
    			type: 'POST'
    		});
    		$envio.success(function(){
    			//$("#TableData").load("#table-admin.php #TableData");
    			location.reload();
    		});
    	}

    	function DesactivarRol(id){
    		var parametros = {
    			"id" : id,
    			"operacion1" : "flag",
    			"estado" : "N"
    		};
    		var $envio = $.ajax({
    			url: '../database/process_rol.php',
    			data: parametros,
    			type: 'POST'
    		});
    		$envio.success(function(){
    			//$("#TableData").load("#table-admin.php #TableData");
    			location.reload();
    		});
    	}

    	function EditPriv(idPriv, cols, idRol, permiso) {
    		//console.log(idPriv+" - "+cols+" - "+idRol+" - "+permiso);
    		$("#operacion2").val("editar");
			$("#campos").focus().val(cols);
			$("#idPrivilegio").val(idPriv);
			
			document.ready = document.getElementById("selectRol").value = idRol;
			document.ready = document.getElementById("selectPermiso").value = permiso;
    	}

    	/*function agregarCol(columna) {
    		$("#campos").focus().val(columna);
    	}*/

	</script>


</body>
</html>