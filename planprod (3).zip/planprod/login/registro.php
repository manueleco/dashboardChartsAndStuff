<?php 

require("ldap.php");
require("../database/conn.php");

//PHP MAILER
include("../phpmailer/class.phpmailer.php");
include("../phpmailer/class.smtp.php");

header("Content-Type: text/html; charset=utf-8"); 
mysqli_set_charset($mysqli, "utf8");

$usr = $_POST["name"];
$pas = $_POST["pass"];
$InfoUsuario = mailboxpowerloginrd($usr,$pas);
$usuario = $InfoUsuario[0]["samaccountname"][0];
$correo = $InfoUsuario[0]["mail"][0];
$nombreAD = $InfoUsuario[0]["cn"][0];

if($usuario == "0" || $usuario == '') {
    $_SERVER = array(); 
    $_SESSION = array();
    $arrResult["registrado"] = "FAIL";
}
else {
    $query = mysqli_query($mysqli,"SELECT * FROM PP_USUARIO WHERE USRNOMBRE = '$usuario'")
    or die('error: '.mysqli_error($mysqli));
    
    while ($row = mysqli_fetch_assoc($query)) {
        $arrResult["nameUser"] = $userName =  $row["USRNOMBRE"];
        $arrResult["estado"] = $estado = $row["ESTADOSOLICITUD"];
    }

    if ($userName == $usuario) {
        $arrResult["nombreUsuario"] = $userName;
    }
    else {
        $date = date("Y-m-d H:i:s");
        $query = mysqli_query($mysqli,"INSERT INTO PP_USUARIO (USRNOMBRE, NOMBREAD, CORREO, ESTADOSOLICITUD, FECHASOLICITUD) VALUES ('$usuario','$nombreAD','$correo','P','$date');")
        or die('error: '.mysqli_error($mysqli));

        $mail = new PHPMailer(); 
        $mail->IsSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        $mail->Port = 465;
        $mail->SMTPSecure = "ssl";
        $mail->Username   = "forward@tata.com.gt";
        $mail->Password = "axxe3128";
        $mail->SetFrom("forward@tata.com.gt","Checklist Preproduccion");
        $mail->AddAddress("jsaravia@tata.com.gt","Josué Saravia");
        $mail->AddAddress("afperez@tata.com.gt","Abner Pérez");
        $mail->Subject = "Solicitud de ingreso - Checklist Preproduccion";
        $mail->Body = "Hola, tienes una nueva solicitud de ingreso:
                     \rRealizada por ".$nombreAD." con usuario: ".$usuario.", verificar la bandeja de entrada en la administracion de usuarios.
                     \rSaludos. (Este es un mensaje automatico, no responder)";
        $mail->Send();

        $arrResult["registrado"] = "OK";
    }    
}

print json_encode($arrResult);
mysqli_close($mysqli);

?>