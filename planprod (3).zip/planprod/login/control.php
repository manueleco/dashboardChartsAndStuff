<?php 

require("ldap.php");
require("../database/conn.php");

header("Content-Type: text/html; charset=utf-8"); 
mysqli_set_charset($mysqli, "utf8");

$usr = $_POST["name"]; 
$pas = $_POST["pass"];
$InfoUsuario = mailboxpowerloginrd($usr,$pas); 
$usuario = $InfoUsuario[0]["samaccountname"][0];
$correo = $InfoUsuario[0]["mail"][0];
$nombreAD = $InfoUsuario[0]["cn"][0];

if($usuario == "0" || $usuario == '') {
    $_SERVER = array(); 
    $_SESSION = array();
    $arrResult["ingreso"] = "FAIL";
} 
else {
    $query = mysqli_query($mysqli,"SELECT ID, USRNOMBRE, ROLACCESO FROM PP_USUARIO WHERE USRNOMBRE = '$usuario' AND ESTADOSOLICITUD = 'A';")
    or die('error: '.mysqli_error($mysqli));
    
    while ($row = mysqli_fetch_assoc($query)) {
        $userName = $row["USRNOMBRE"];
        $Id_User = $row["ID"];
        $RolUser = $row["ROLACCESO"];
    }

    if ($userName == $usuario) {
        session_start(); 
        $_SESSION["user"] = $usuario;
        $_SESSION["nombreAD"] = $nombreAD;
        $_SESSION["iduser"] = $Id_User;
        $_SESSION["RolUser"] = $RolUser;
        $_SESSION["autentica"] = "SIP";
        $arrResult["ingreso"] = "OK";

        $queryLOG = mysqli_query($mysqli,"SELECT * FROM PP_ULOG U WHERE USUARIO = '$usuario'")
        or die('error: '.mysqli_error($mysqli));
        $row_cnt = mysqli_num_rows($queryLOG);
        //$arrResult["log_info"] = $row_cnt;
        if ($row_cnt > 0) {
            while ($row = mysqli_fetch_assoc($queryLOG)) {
                $idlog = $row["IDLOG"];
                $user = $row["USUARIO"];
                //$arrResult["log_info"] = "LOG UPDATE";
                $queryUP = mysqli_query($mysqli,"UPDATE PP_ULOG SET ULTIM_ACCESO = NOW() WHERE IDLOG = $idlog")
                or die('error: '.mysqli_error($mysqli));
            }
        } else {
            //$arrResult["log_info"] = "LOG INSERT";
            $queryIN = mysqli_query($mysqli,"INSERT INTO PP_ULOG (USUARIO, NOMBRE, CORREO, ROL, ULTIM_ACCESO) VALUES ('$usuario', '$nombreAD', '$correo', '$RolUser', NOW());")
            or die('error: '.mysqli_error($mysqli));
        }
    }
    
    else {
        $query = mysqli_query($mysqli,"SELECT USRNOMBRE FROM PP_USUARIO WHERE USRNOMBRE = '$usuario' AND ESTADOSOLICITUD = 'P';")
        or die('error: '.mysqli_error($mysqli));
        
        while ($row = mysqli_fetch_assoc($query)) {
            $userName = $row["USRNOMBRE"];
        }

        if ($userName == $usuario) {
            $arrResult["ingreso"] = "PENDIENTE";
        } else {
            $arrResult["ingreso"] = "REGISTRAR";
        }
    }
}

print json_encode($arrResult);
mysqli_close($mysqli);

?>