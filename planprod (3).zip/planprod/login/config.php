<?php
    define('DOMINIO','TATAD.COM.GT');
    define('DN', 'OU=Usuarios,OU=TATA_Administrator, DC=TATAD,DC=COM,DC=GT');
    //OU=Usuarios,OU=TATA_Administrator, DC=TATAD,DC=COM,DC=GT
    //OU=Administradores,OU=Usuarios,OU=TATA_Administrator,DC=TATAD,DC=COM,DC=GT
?>