<?php

  require_once("config.php");
  
  /*$usr = "cjimenez"; 
  $pas = "Accesorios1";
  $usuario = mailboxpowerloginrd($usr,$pas);

  print "<b>cn: </b>".$usuario[0]["cn"][0]."<br>";
  print "<b>sn: </b>".$usuario[0]["sn"][0]."<br>";
  print "<b>Departamento: </b>".$usuario[0]["department"][0]."<br>";
  print "<b>Puesto: </b>".$usuario[0]["title"][0]."<br>";
  print "<b>givenname: </b>".$usuario[0]["givenname"][0]."<br>";
  print "<b>distinguishedname: </b>".$usuario[0]["distinguishedname"][0]."<br>";
  print "<b>instancetype: </b>".$usuario[0]["instancetype"][0]."<br>";
  print "<b>whencreated: </b>".$usuario[0]["whencreated"][0]."<br>";
  print "<b>whenchanged: </b>".$usuario[0]["whenchanged"][0]."<br>";
  print "<b>displayname: </b>".$usuario[0]["displayname"][0]."<br>";
  print "<b>usncreated: </b>".$usuario[0]["usncreated"][0]."<br>";
  print "<b>usnchanged: </b>".$usuario[0]["usnchanged"][0]."<br>";
  print "<b>name: </b>".$usuario[0]["name"][0]."<br>";
  print "<b>objectguid: </b>".$usuario[0]["objectguid"][0]."<br>";
  print "<b>useraccountcontrol: </b>".$usuario[0]["useraccountcontrol"][0]."<br>";
  print "<b>badpwdcount: </b>".$usuario[0]["badpwdcount"][0]."<br>";
  print "<b>codepage: </b>".$usuario[0]["codepage"][0]."<br>";
  print "<b>countrycode: </b>".$usuario[0]["countrycode"][0]."<br>";
  print "<b>badpasswordtime: </b>".$usuario[0]["badpasswordtime"][0]."<br>";
  print "<b>scriptpath: </b>".$usuario[0]["scriptpath"][0]."<br>";
  print "<b>pwdlastset: </b>".$usuario[0]["pwdlastset"][0]."<br>";
  print "<b>primarygroupid: </b>".$usuario[0]["primarygroupid"][0]."<br>";
  print "<b>objectsid: </b>".$usuario[0]["objectsid"][0]."<br>";
  print "<b>admincount: </b>".$usuario[0]["admincount"][0]."<br>";
  print "<b>accountexpires: </b>".$usuario[0]["accountexpires"][0]."<br>";
  print "<b>samaccountname: </b>".$usuario[0]["samaccountname"][0]."<br>";
  print "<b>samaccounttype: </b>".$usuario[0]["samaccounttype"][0]."<br>";
  print "<b>userprincipalname: </b>".$usuario[0]["userprincipalname"][0]."<br>";
  print "<b>objectcategory: </b>".$usuario[0]["objectcategory"][0]."<br>";
  print "<b>dscorepropagationdata: </b>".$usuario[0]["dscorepropagationdata"][0]."<br>";
  print "<b>lastlogontimestamp: </b>".$usuario[0]["lastlogontimestamp"][0]."<br>";
  print "<b>dn: </b>".$usuario[0]["dn"]."<br>";
  print "<b>lastlogontimestamp: </b>".$usuario[0]["lastlogontimestamp"][0]."<br>";
  print "<b>Correo: </b>".$usuario[0]["mail"][0]."<br>";*/

  /*print "<pre>";
  print_r($usuario);
  print "</pre>";*/

  function mailboxpowerloginrd($user,$pass){

    $ldaprdn = trim($user).'@'.DOMINIO;
    $ldappass = trim($pass);
    $ds = DOMINIO;
    $dn = DN;
    $puertoldap = 389;
    $ldapconn = ldap_connect($ds,$puertoldap);

    ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION,3);
    ldap_set_option($ldapconn, LDAP_OPT_REFERRALS,0);

    $ldapbind = @ldap_bind($ldapconn, $ldaprdn, $ldappass);
    
    if ($ldapbind) {
      $filter="(|(SAMAccountName=".trim($user)."))";
      //$fields = array("SAMAccountName");
      $sr = @ldap_search($ldapconn, $dn, $filter/*, $fields*/);  
      $info = @ldap_get_entries($ldapconn, $sr);
      
    }
    else {
      $array=0;
    }

    ldap_close($ldapconn);
    return $info;
  }

?>
