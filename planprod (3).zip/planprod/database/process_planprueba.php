<?php 

	//require("../login/seguridad.php");
	include('conn.php');
	header('Content-Type: text/html; charset=UTF-8');
	mysqli_set_charset($mysqli, "utf8");

	$userSes = $_SESSION["iduser"];

	$id = $_POST["id"];
	$etapa = trim($_POST["etapa"]);
	$op = $_POST["op"];
	$consulta = $_POST["query"];

	

	//$fecha = NOW();

	//echo $consulta;

	$mystring = $consulta;
	$findme   = 'CALL';
	$pos = strpos($mystring, $findme);
	$etapa = strtoupper($etapa);

	//Consulta del id del plan para ver data a actualizar
	$query = mysqli_query($mysqli, "SELECT * FROM PRUEBA_PP_SEMANAL WHERE IDPLAN = $id")
	or die('Error en query plan: '.mysqli_error($mysqli));
	 
	while ($strData = mysqli_fetch_assoc($query)) {
		$idPlan = $strData["IDPLAN"];
		$orden = $strData["ORDENDESC"];
		$linea = $strData["DESCLINEA"];
		$inicioProd = $strData["INICIOPROD"];
	}
	echo $idPlan." - ".$orden." - ".$inicioProd." - ".$fecha." - ".$etapa." - ".$userSes;


	if ($pos !== false) {
		if ($op == "0") {
			if (!$mysqli->query("UPDATE PP_ETAPAS
				SET $etapa = 'P'
				WHERE  IDPLAN = $id; ")) {
				echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
			}

			$cambio = "N - P";
			if (!$mysqli->query("INSERT INTO PP_LOG (IDPLAN, ORDEN, LINEA, FEC_INICIOPROD, FEC_CAMBIO, ETAPA, CAMBIO_ESTADO, USUARIO) VALUES ($idPlan,'$orden','$linea','$inicioProd',NOW(),'$etapa','$cambio','$userSes');")) {
				echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
			}

		}

		else if ($op == "1") {
			if (!$mysqli->query("UPDATE PP_ETAPAS
				SET $etapa = 'Y'
				WHERE  IDPLAN = $id; ")) {
				echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
			}

			$cambio = "P - Y";
			if (!$mysqli->query("INSERT INTO PP_LOG (IDPLAN, ORDEN, LINEA, FEC_INICIOPROD, FEC_CAMBIO, ETAPA, CAMBIO_ESTADO, USUARIO) VALUES ($idPlan,'$orden','$linea','$inicioProd',NOW(),'$etapa','$cambio','$userSes');")) {
				echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
			}
		}

		else if ($op == "2") {
			if (!$mysqli->query("UPDATE PP_ETAPAS
				SET $etapa = 'N'
				WHERE  IDPLAN = $id; ")) {
				echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
			}

			$cambio = "Y - N";
			if (!$mysqli->query("INSERT INTO PP_LOG (IDPLAN, ORDEN, LINEA, FEC_INICIOPROD, FEC_CAMBIO, ETAPA, CAMBIO_ESTADO, USUARIO) VALUES ($idPlan,'$orden','$linea','$inicioProd',NOW(),'$etapa','$cambio','$userSes');")) {
				echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
			}
		}
	}

	else {
		$cadena = str_replace('SELECT', '', $consulta);
		$palabra = strrpos($cadena, "FROM");
	 	
	 	if ($palabra === false) {
	 		echo "Palabra FROM no encontrada en la cadena.";
	 	}
	 	else {
	 		//echo "FROM se encuentra en la posicion: ".$palabra;
	 		$cadena = substr($cadena, 0, $palabra);
	 	}

	 	echo $cadena;

		$cols = split(',', $cadena);
		$columna = strtoupper($cols[$etapa]);
		$columna = trim($columna);


	 	if ($op == "0") {
			if (!$mysqli->query("UPDATE PP_ETAPAS
				SET $columna = 'P'
				WHERE  IDPLAN = $id; ")) {
				echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
			}

			$cambio = "N - P";
			if (!$mysqli->query("INSERT INTO PP_LOG (IDPLAN, ORDEN, LINEA, FEC_INICIOPROD, FEC_CAMBIO, ETAPA, CAMBIO_ESTADO, USUARIO) VALUES ($idPlan,'$orden','$linea','$inicioProd',NOW(),'$columna','$cambio','$userSes');")) {
				echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
			}
		}

		else if ($op == "1") {
			if (!$mysqli->query("UPDATE PP_ETAPAS
				SET $columna = 'Y'
				WHERE  IDPLAN = $id; ")) {
				echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
			}

			$cambio = "P - Y";
			if (!$mysqli->query("INSERT INTO PP_LOG (IDPLAN, ORDEN, LINEA, FEC_INICIOPROD, FEC_CAMBIO, ETAPA, CAMBIO_ESTADO, USUARIO) VALUES ($idPlan,'$orden','$linea','$inicioProd',NOW(),'$columna','$cambio','$userSes');")) {
				echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
			}
		}

		else if ($op == "2") {
			if (!$mysqli->query("UPDATE PP_ETAPAS
				SET $columna = 'N'
				WHERE  IDPLAN = $id; ")) {
				echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
			}

			$cambio = "Y - N";
			if (!$mysqli->query("INSERT INTO PP_LOG (IDPLAN, ORDEN, LINEA, FEC_INICIOPROD, FEC_CAMBIO, ETAPA, CAMBIO_ESTADO, USUARIO) VALUES ($idPlan,'$orden','$linea','$inicioProd',NOW(),'$columna','$cambio','$userSes');")) {
				echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
			}
		}
	}

	mysqli_close($mysqli);



?>



