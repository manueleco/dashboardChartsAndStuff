<?php 

	include('conn.php');
	header('Content-Type: text/html; charset=UTF-8');
	mysqli_set_charset($mysqli, "utf8");

	//$id = $_POST["id"];
	$area = $_POST["area"];
	$old_area = $_POST["old_area"];
	$op = $_POST["operacion"];
	$fecha = date("Y-m-d H:i:s");
	
	$area = str_replace(' ', '', $area);
	
	$area = strtoupper($area);
	$old_area = strtoupper($old_area);

	if ($op == "agregar") {
		if (!$mysqli->query("ALTER TABLE PP_SEMANAL
							 ADD COLUMN {$area} ENUM('Y','N','P') NULL DEFAULT 'N';")) {
			echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
		}
	}

	else if ($op == "editar") {
		if (!$mysqli->query("ALTER TABLE PP_SEMANAL CHANGE {$old_area} {$area} ENUM('Y','N','P') NULL DEFAULT 'N';")) {
			echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
		}	
	}

	else if ($op == "eliminar") {
		if (!$mysqli->query("ALTER TABLE PP_SEMANAL
							 DROP COLUMN {$area};")) {
			echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
		}	
	}

	mysqli_close($mysqli);

?>