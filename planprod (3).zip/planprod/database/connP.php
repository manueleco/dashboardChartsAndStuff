<?php 

$server   = "168.2.0.200";
$username = "root";
$password = "A6.t47@Da7A";
$database = "proaktiv";

$mysqliP = new mysqli($server, $username, $password, $database);

	if ($mysqliP->connect_error) {
	    die('Error al conectar a la BD proaktiv: '.$mysqliP->connect_error);
	}

?>