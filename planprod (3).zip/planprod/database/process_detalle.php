<?php
	include('conn.php');
	include('connP.php');
	
	header('Content-Type: text/html; charset=UTF-8');
	mysqli_set_charset($mysqli, "utf8");

	$id = $_POST["id"];

	if (!empty($id)) {
		$query = mysqli_query($mysqli,"SELECT * FROM PP_SEMANAL WHERE IDPLAN = '$id'")
	    or die('error: '.mysqli_error($mysqli));
	    
	    while ($row = mysqli_fetch_assoc($query)) {
	        $arrResult["idplan"] =  $id = $row["IDPLAN"];
	        $arrResult["ordendesc"] = $ordenColor = $row["ORDENDESC"];
	        $arrResult["orden"] = $orden = $row["ORDEN"];
	        $arrResult["estilo"] = $estilo = $row["ESTILO"];
	        $arrResult["cliente"] = $cliente = $row["CLIENTE"];
	    }


	    //**PROAKTIV**
	    $color = split("::", $ordenColor);
	    $colDesc = $color[1];

	    $queryStlColor = mysqli_query($mysqliP,"SELECT S.StlNumber, C.ClrShortDesc
									   FROM Styles S 
									   INNER JOIN Colors C ON C.ClrNumber = S.ClrNumber
									   WHERE S.StlNumber = $estilo AND C.ClrShortDesc = '$colDesc';")
	    or die('Error query estilo-color: '.mysqli_error($mysqliP));
	    
	    while ($row = mysqli_fetch_assoc($queryStlColor)) {
	    	$arrResult["estilo"] =  $style = $row["StlNumber"];
	        $arrResult["color"] =  $clr = $row["ClrShortDesc"];	        
	    }

	    /*echo $style;
	    echo $clr;*/

	    print json_encode($arrResult);

	}

	//TROQUELES SON DE HOJA TECNICA
	//CLISHES SON DE HOJA TECNICA
	//RODILLOS PKS HOJA TECNICA
	//


	mysqli_close($mysqli);
	mysqli_close($mysqliP);
?>