<?php 

	include('conn.php');
	header('Content-Type: text/html; charset=UTF-8');
	mysqli_set_charset($mysqli, "utf8");

	$id = $_POST["id"];

	$op1 = $_POST["operacion1"];
	$nom = $_POST["rol"];
	$estado1 = "Y";
	$estado = $_POST["estado"];
	
	$op2 = $_POST["operacion2"];
	$columnas = $_POST["campos"];
	$idrol = $_POST["selectRol"];
	$permiso = $_POST["selectPermiso"];
	$idprivilegio = $_POST["idPrivilegio"];
	

	//FORMULARIO ROLES
	if ($op1) {
		if ($op1 == "agregar") {
			if (!$mysqli->query("INSERT INTO PP_ROL (ROLNOMBRE, ACTIVO) VALUES ('$nom', '$estado1');")) {
				echo "Error ROL INSERT: (" . $mysqli->errno . ") " . $mysqli->error;
			}
		} 

		else if ($op1 == "editar") {
			if (!$mysqli->query("UPDATE PP_ROL SET ROLNOMBRE = '$nom' WHERE  ID = $id;")) {
				echo "Error ROL RENOMBRAR: (" . $mysqli->errno . ") " . $mysqli->error;
			}
		}

		else if ($op1 == "flag") {
			if (!$mysqli->query("UPDATE PP_ROL SET ACTIVO = '$estado' WHERE  ID = $id;")) {
				echo "Error ROL DESACTIVAR: (" . $mysqli->errno . ") " . $mysqli->error;
			}
		}
	}

	//FORMULARIO PRIVILEGIOS
	else if ($op2) {
		if ($op2 == "agregar") {
			if (!$mysqli->query("INSERT INTO PP_PRIVILEGIO (ROLUSER, COLUMNAS, PERMISOEDICION) VALUES ('$idrol', '$columnas', '$permiso');")) {
				echo "Error PRIVILEGIO INSERT: (" . $mysqli->errno . ") " . $mysqli->error;
			}
		} 

		else if ($op2 == "editar") {
			if (!$mysqli->query("UPDATE PP_PRIVILEGIO SET 
								 ROLUSER = $idrol,
								 COLUMNAS = '$columnas',
								 PERMISOEDICION = '$permiso'
								 WHERE  ID = $idprivilegio")) {
				echo "Error PRIVILEGIO EDITAR: (" . $mysqli->errno . ") " . $mysqli->error;
			}
		}

		/*else if ($op2 == "flag") {
			if (!$mysqli->query("UPDATE PP_PRIVILEGIO SET ACTIVO = '$estado' WHERE  ID = $id;")) {
				echo "Error PRIVILEGIO : (" . $mysqli->errno . ") " . $mysqli->error;
			}
		}*/
	}	

	mysqli_close($mysqli);

?>
