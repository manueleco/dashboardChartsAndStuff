<?php 

//include_once 'config.php';

$serverDWH = "168.2.0.97";
$userDWH = "DWHUSER";
$passDWH = "DWH.t47@Da7A";
$bdDWH = "DWH";

$mysqli = new mysqli($serverDWH, $userDWH, $passDWH, $bdDWH);

	if ($mysqli->connect_error) {
	    die('Error al conectar a la BD DWH: '.$mysqli->connect_error);
	}

?>