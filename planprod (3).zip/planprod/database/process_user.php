<?php

	include('conn.php');
	header('Content-Type: text/html; charset=UTF-8');
	mysqli_set_charset($mysqli, "utf8");

	$op = $_POST["op"];
	$id = $_POST["id"];
	$rol = $_POST["rol"];
	$rep = $_POST["idRep"];
	$acceso = $_POST["acceso"];
	$fecha = date("Y-m-d H:i:s");

	if ($op == "update") {
		if (!$mysqli->query("UPDATE PP_USUARIO 
			SET ESTADOSOLICITUD = '$acceso'
			WHERE  ID = $id; ")) {
			echo "Error al crear el reporte: (" . $mysqli->errno . ") " . $mysqli->error;
		}
	}

	if ($op == "AddPrivs") {
		//Agrego el rol al usuario
		if (!$mysqli->query("UPDATE PP_USUARIO SET ROLACCESO = $rol WHERE ID = $id")) {
			echo "Error al crear el reporte: (" . $mysqli->errno . ") " . $mysqli->error;
		}
	}

	if ($op == "delete") {
		$query = mysqli_query($mysqli,"DELETE FROM PP_USUARIO WHERE ID = $id")
		or die('error: '.mysqli_error($mysqli));
	}

	print json_encode($arrResult);
	mysqli_close($mysqli);

?>