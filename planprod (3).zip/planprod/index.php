<!--
Proyecto:CONTROL PLAN DE PRODUCCION
Descripción: 
Autor: Josué Saravia - jsaravia@tata.com.gt
Fecha Inicio: 31-08-2018
-->

<?php @session_start(); ?>

<!DOCTYPE html>
<html>
<head>
    <link type="text/css" rel="stylesheet" href="materialize/icons/icons.css"><!--Import Google Icon Font-->
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/><!--Import materialize.css-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/><!--Let browser know website is optimized for mobile-->
    <link type="text/css" rel="stylesheet" href="materialize/css/estilos.css"><!-- Estilos personalizados -->
    <meta charset="utf-8"><!-- Importa la libreria de caracteres a utilizar-->
    <title>PLAN DE PRODUCCION</title>
    <link rel="icon" href="images/logo/calendar1.png" sizes="30x30">

    <style type="text/css">
    /* label focus color */
    .input-field input[type=password]:focus + label, .materialize-textarea:focus:not([readonly]) + label {
        color: black !important;
    }
    /* label underline focus color */
    .input-field input[type=password]:focus, .materialize-textarea:focus:not([readonly]) {
        border-bottom: 1px solid black !important;
        box-shadow: 0 1px 0 0 black !important;
    }
    
</style>

</head>

<body class="" onkeypress="enterLogin(event);">
    <div class="row">
        <div class="container">
            <div class="col s12 m6 offset-m3 z-depth-4" style="margin-top: 7%; opacity: 0.9; background-color: white;">
                <div class="row" style="padding: 30px;">
                    <form autocomplete="off">
                        <div>
                            <center><img src="images/logo/caltime.png" class="" style="width: 50%; height: 50%;"/></center>
                        </div>
                        <div class="input-field">
                            <i class="material-icons prefix black-text">person</i>
                            <input name="usuario" id="usuario" type="text" maxlength="50">
                            <label for="usuario">Usuario</label>
                        </div>
                        <div class="input-field">
                            <i class="material-icons prefix black-text">lock</i>
                            <input name="clave" id="clave" type="password" maxlength="50">
                            <label for="clave">Password</label>
                        </div>
                        <div>
                            <a type="button" onclick="login();" class="btn blue darken-4 waves-effect lightness right col s12">Ingresar</a>
                        </div>
                        <div>
                            <a style="margin-top: 10px;" onclick="registro();" class="btn grey darken-1 waves-effect lightness col s12">Registrar</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery-2.1.1.min.js"></script><!--Import Jquery-->
    <script type="text/javascript" src="materialize/js/materialize.min.js"></script><!--Import Materialize-->
    <script type="text/javascript" src="js/check_login.js"></script><!--validacion login -->
    <script src="../js/materializeEffects.js"></script><!-- Funciones de jquery que necesita materializecss -->

</body>
</html>

<?php exit(); ?>