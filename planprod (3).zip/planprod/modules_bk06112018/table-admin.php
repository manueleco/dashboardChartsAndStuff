<!--
Proyecto:CONTROL PLAN DE PRODUCCION
Descripción: 
Autor: Josué Saravia - jsaravia@tata.com.gt
Fecha Inicio: 31-08-2018
-->

<?php

require("../login/seguridad.php");
require('funcs/table_function.php');
include("menu_nav.php");

$userRol = $_SESSION["RolUser"];
$userSes = $_SESSION["iduser"];

?>

<!DOCTYPE html>
<html lang="es">

<style type="text/css">
@media only screen and (min-width: 600px) {
	#linDate {
		margin-left: 75px;
	}
}
@media only screen and (max-width: 600px) {
	#linDate {
		margin-left: 10px;
		width: 300px;
	}
}

.cent {
	text-align: center;
}

td {
	width: 10px;
	height: 10px;
}
</style>

<body>

	<div class="row">
	</div>

	<main class="control">
		<form autocomplete="off" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
			<div class="left-align">
				<div class="col s12 m12">
					<div class="row" id="linDate">

						<div id="etapaDiv">
							<select id="selectEtapa" name="selectEtapa" class="col s12 m2" style="margin-right: 50px;">
								<option selected="selected" disabled="disabled" value="0">ETAPA</option>
								<!-- <option value="CORTE">CORTE</option>-->
								<option value="ENSAMBLE">ENSAMBLE</option>
								<!-- <option value="LAMINADO">LAMINADO</option>-->
							</select>
						</div> 

						<select id="selectLinea" name="selectLinea" class="col s12 m2" style="margin-right: 50px;" onchange="OcultaEtapa();">
							<option selected="selected" disabled="disabled" value="0">LINEA/AREA</option>
							<?php
							require("../database/conn.php");
							mysqli_set_charset($mysqli, "utf8");
							$strQuery = mysqli_query($mysqli, "SELECT LINEA, DESCRIPCION FROM LINEAS_MAESTRO WHERE DESCRIPCION LIKE '%ENSAMBLE%';") or die('Error LINEAS_MAESTRO DWH: '.mysqli_error($mysqli));
							while($row = $strQuery->fetch_array(MYSQLI_ASSOC)){ ?>
								<option value="<?php echo $row["DESCRIPCION"]; ?>"><?php echo $row["LINEA"]." - ".$row["DESCRIPCION"]; ?></option>
							<?php }
							$mysqli->close();
							?>
						</select>

						<select id="selectSemana" name="selectSemana" class="col s12 m2" style="margin-right: 50px;" onchange="OcultaFecha();">
							<option selected="selected" disabled="disabled" value="0">SEMANA</option>
							<?php
							require("../database/conn.php");
							mysqli_set_charset($mysqli, "utf8");
							$strQuery = mysqli_query($mysqli, "SELECT WEEK(S.INICIOPROD,1) SEMANA_INPROD FROM PP_SEMANAL S GROUP BY SEMANA_INPROD;") or die('Error SEMANA_INPROD DWH: '.mysqli_error($mysqli));
							while($row = $strQuery->fetch_array(MYSQLI_ASSOC)){ ?>
								<option value="<?php echo $row["SEMANA_INPROD"]; ?>"><?php echo " SEMANA ".$row["SEMANA_INPROD"]; ?></option>
							<?php }
							$mysqli->close();
							?>
						</select>

						<div id="fechaDiv">
							<?php
							require("../database/conn.php");
							$strQuery = mysqli_query($mysqli, "SELECT MIN(ACTUALIZACION) AS MIN_FEC FROM PP_SEMANAL;") or die('Error MIN_FECHA DWH: '.mysqli_error($mysqli));
							while($row = $strQuery->fetch_array(MYSQLI_ASSOC)){
								$min_fec = $row["MIN_FEC"];
							}
							$mysqli->close();
							?>
							<input class="col s12 m2" type="date" name="fecha" id="fecha" style="margin-right: 50px;" min="<?php echo $min_fec; ?>">
						</div>
						
					</div>
					<div class="row">
						<div style="margin-left: 5%;">
							<button type="submit" class="btn grey col s8 m3"><b>Consultar</b></button>
						</div>
					</div>
				</div>
			</div>	
		</form>

		<div class="left-align" style="margin-left: 75px;" id="control-panel">
			<p>
				<?php 
				require("../database/conn.php");
				mysqli_set_charset($mysqli, "utf8");

				$queryCols = mysqli_query($mysqli, "SELECT ROLNOMBRE FROM PP_ROL WHERE ACTIVO = 'Y' AND ID = $userRol;") 
				or die('Error table-admin 1: '.mysqli_error($mysqli));
				
				while ($strData = mysqli_fetch_assoc($queryCols)) {
					echo '<b><p class="left-align">'.$rol = $strData["ROLNOMBRE"].'</p></b>';
				}
				?>
			</p>
			<p>
				<label>
					<input type="checkbox" _disabled="" />
					<span>En proceso</span>
				</label>
			</p>
			<p>
				<label>
					<input type="checkbox" checked="checked" _disabled="" />
					<span>Despachado</span>
				</label>
			</p>
			<p>
				<label>
					<input type="checkbox" class="filled-in" checked="checked" _disabled="" />
					<span>Recibido</span>
				</label>
			</p>
		</div>

		<div class="row">
			<div class="col s11" id="table">
				<div class="divider"></div>

				<?php
				//CONEXION
				require("../database/conn.php");
				mysqli_set_charset($mysqli, "utf8");

				//VALIDO QUE AL MENOS UN FILTRO TRAIGA DATA
				if (!empty($_POST["selectLinea"]) || !empty($_POST["selectEtapa"]) || !empty($_POST["fecha"]) || !empty($_POST["selectSemana"])) {

					$linea = $_POST["selectLinea"];
					$etapa = $_POST["selectEtapa"];
					$fec = $_POST["fecha"];
					$semana = $_POST["selectSemana"];
					
					echo "<p><b>ETAPA:</b> - ".$etapa."</p>";
					echo "<p><b>LINEA:</b> - ".$linea."</p>";
					echo "<p><b>SEMANA:</b> - ".$semana."</p>";
					echo "<p><b>FECHA:</b> - ".$fec."</p>";
					
					//CALCULO SEMANA ACTUAL
					$querySemAct = mysqli_query($mysqli, "SELECT WEEK(CURDATE(),1) SEMANA_ACTUAL FROM PP_SEMANAL LIMIT 1;")
					or die('Error Semana actual: '.mysqli_error($mysqli));
					while ($strData = mysqli_fetch_assoc($querySemAct)) {
						$semAct = $strData["SEMANA_ACTUAL"];
					}

					//$semAct = 39;
					if (empty($semana)) {
						$semana = $semAct;
					}

					if (!empty($fec)) {
						//CALCULO SEMANA SEGUN INICIO DE PRODUCCION
						$querySemIni = mysqli_query($mysqli, "SELECT WEEK(INICIOPROD,1) SEMANA_INPROD FROM PP_SEMANAL WHERE INICIOPROD = '$fec;' LIMIT 1;")
						or die('Error Semana inProd: '.mysqli_error($mysqli));
						while ($strData = mysqli_fetch_assoc($querySemIni)) {
							$semIni = $strData["SEMANA_INPROD"];
						}
						$semana = "0";
					}
					
					//OPERACIONES PARA VISUALIZACION Y PRIVILEGIOS DE USUARIOS
					$queryPrivs = mysqli_query($mysqli, "SELECT * FROM PP_PRIVILEGIO WHERE ROLUSER = $userRol;") 
					or die('Error table-admin 2: '.mysqli_error($mysqli));
					while ($row = mysqli_fetch_assoc($queryPrivs)) {
						$columnas = strtoupper( $row["COLUMNAS"] );

						if ($semana == $semAct || $semIni == $semAct) {
							$permiso = $row["PERMISOEDICION"];
						} else {
							$permiso = 1;
							echo '<p class="LEFT"><b style="color:red;">NOTA:</b> Los checks de las semanas diferentes a la actual no pueden actualizarse.</p>';
						}

						//EN ESTA VERSION SE FILTRAN TODOS LOS QUERYS POR ETAPA: **ENSAMBLE** || Se seleccionan las columnas para visualizar por default y las agregadas en los privilegios.
						if($columnas != "*") {

							//CUANDO SOLO UNO DE LOS CAMPOS ESTA VACIO
							if (!empty($linea) && !empty($fec) && !empty($etapa) && !empty($semana)) {
								$consulta = "SELECT IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN, ".$columnas." FROM PP_SEMANAL WHERE DESCLINEA LIKE '%$linea%' AND ETAPA = '$etapa' AND INICIOPROD = '$fec' AND WEEK(INICIOPROD,1) = '$semana';";
							}
							else if (!empty($linea) && !empty($etapa) && !empty($semana) && empty($fec)) {
								$consulta = "SELECT IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN, ".$columnas." FROM PP_SEMANAL WHERE DESCLINEA LIKE '%$linea%' AND ETAPA = '$etapa' AND WEEK(INICIOPROD,1) = '$semana';";
							}
							else if (!empty($linea) && !empty($fec) && !empty($semana) && empty($etapa)) {
								$consulta = "SELECT IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN, ".$columnas." FROM PP_SEMANAL WHERE DESCLINEA LIKE '%$linea%' AND INICIOPROD = '$fec' AND WEEK(INICIOPROD,1) = '$semana';";
							}
							else if (!empty($fec) && !empty($etapa) && !empty($semana) && empty($linea)) {
								$consulta = "SELECT IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN, ".$columnas." FROM PP_SEMANAL WHERE ETAPA = '$etapa' AND INICIOPROD = '$fec' AND WEEK(INICIOPROD,1) = '$semana' AND DESCLINEA LIKE '%ENSAMBLE%';";
							}
							else if (!empty($fec) && !empty($etapa) && !empty($linea) && empty($semana)) {
								$consulta = "SELECT IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN, FAJAS, RODILLOSPKS, TROQUELES, CLISHES, HEBILLAS, HANGERS, PASADORES, TICKETS FROM PP_SEMANAL WHERE ETAPA = '$etapa' AND INICIOPROD = '$fec' AND DESCLINEA LIKE '%$linea%';";
							}

							//CUANDO DOS CAMPOS ESTAN VACIOS, VALIDACION PARTIENDO CON ETAPA
							if (!empty($etapa) && !empty($linea) && empty($semana) && empty($fec)) {
								$consulta = "SELECT IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN, ".$columnas." FROM PP_SEMANAL WHERE DESCLINEA LIKE '%$linea%' AND ETAPA = '$etapa';";
							}
							else if (!empty($etapa) && !empty($semana) && empty($linea) && empty($fec)) {
								$consulta = "SELECT IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN, ".$columnas." FROM PP_SEMANAL WHERE ETAPA = '$etapa' AND WEEK(INICIOPROD,1) = '$semana';";
							}
							else if (!empty($etapa) && !empty($fec) && empty($linea) && empty($semana)) {
								$consulta = "SELECT IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN, ".$columnas." FROM PP_SEMANAL WHERE ETAPA = '$etapa'  AND INICIOPROD = '$fec';";
							}

							//VALIDACION CONSULTA, PARTIENDO CON LINEA
							else if (!empty($linea) && !empty($semana) && empty($etapa) && empty($fec)) {
								$consulta = "SELECT IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN, ".$columnas." FROM PP_SEMANAL WHERE DESCLINEA LIKE '%$linea%' AND WEEK(INICIOPROD,1) = '$semana';";
							}
							else if (!empty($linea) && !empty($fec) && empty($etapa) && empty($semana)) {
								$consulta = "SELECT IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN, ".$columnas." FROM PP_SEMANAL WHERE DESCLINEA LIKE '%$linea%' AND INICIOPROD = '$fec';";
							}

							//VALIDACION CONSULTA PARTIENDO CON SEMANA
							else if (!empty($semana) && !empty($fec) && empty($etapa) && empty($linea)) {
								$consulta = "SELECT IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN, ".$columnas." FROM PP_SEMANAL WHERE WEEK(INICIOPROD,1) = '$semana' AND INICIOPROD = '$fec';";
							}

							else if (empty($linea) || empty($fec) || empty($etapa) || empty($semana)) {
								if (empty($linea)) {
									$linea = '0';
								}
								if (empty($etapa)) {
									$etapa = '-';
								}
								if (empty($fec)) {
									$fec = '0000-00-00';
								}
								if (empty($semana)) {
									$semana = '0';
								}
								$consulta = "SELECT IDPLAN, DESCLINEA, ORDENDESC, ESTILO, CLIENTE, INICIOPROD, ACTUALIZACION, TOTALPLAN, ".$columnas." FROM PP_SEMANAL WHERE DESCLINEA LIKE '$linea' OR ETAPA = '$etapa' OR INICIOPROD = '$fec' OR WEEK(INICIOPROD,1) = '$semana' AND DESCLINEA LIKE '%ENSAMBLE%';";
							}

							$columnas = str_replace(",", "','", $columnas);
							$columnas = "'".str_replace(" ", "", $columnas)."'";

							$numsCols = mysqli_query($mysqli, "SELECT ORDINAL_POSITION AS num_col, COLUMN_NAME AS nom_col FROM INFORMATION_SCHEMA.COLUMNS  WHERE TABLE_NAME = 'PP_SEMANAL' AND COLUMN_NAME IN ($columnas)") 
							or die('Error table-admin 3: '.mysqli_error($mysqli));
							
							while ($strData = mysqli_fetch_assoc($numsCols)) {
								$cols[] = array('columna' => $strData["nom_col"]);
							}

							BuildTable($consulta, $cols, $permiso);
						}
						//LO ENVIO POR AJAX
						echo '<input id="hid_query" type="hidden" name="hid_query" value="'.$consulta.'">';
					}
				}
				mysqli_close($mysqli);
				?>

			</div>
		</div>
	</main>

	<div id="info_estilo" class="modal" style="max-width: 60%;">
		<div class="modal-content">

			<div id="contentModal">
			</div>

		</div>
		<div class="modal-footer">
			<a class="modal-action modal-close waves-effect waves-green btn-flat">ok</a>
		</div>
	</div>

	<script src="../js/jquery-2.1.1.min.js"></script><!--Import jQuery before materialize.js-->
	<script src="../js/materialize.min.js"></script><!-- Importar funciones de materialize css -->
	<script src="../js/jquery.dataTables.min.js"></script><!-- pluggin de jquery para hacer tablas dinámicas -->
	<script src="../js/materializeEffects.js"></script><!-- Funciones de jquery que necesita materializecss -->
	<script>

		$(document).on("ready", function(){
			mostrarData();
		});

		var mostrarData = function(){
			var table = $('#TableData').DataTable({
				"destroy":true,
				"bPaginate": true,
				"bSort": true,
				"bJQueryUI": false,
				"lengthMenu": [[5, 8, 10, 15, 20, 25, 50, -1], [5, 8, 10, 15, 20, 25, 50, "Todos"]],
				"iDisplayLength": 10,
				"bProcessing": false,
				"language": {
					"sProcessing":     '<div class="progress"><div class="indeterminate"></div></div>',
					"sLengthMenu":     "&nbsp; Mostrar _MENU_ <br>",
					"sZeroRecords":    "No se encontraron datos",
					"sEmptyTable":     "Ningún dato disponible en esta tabla",
					"sInfo":           "Mostrando datos del _START_ al _END_ de un total de _TOTAL_",
					"sInfoEmpty":      "Mostrando datos del 0 al 0 de un total de 0",
					"sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
					"sInfoPostFix":    "",
					"sSearch":         "<br>",
					"sSearchPlaceholder": " BUSCAR EN EL PLAN",
					"sUrl":            "",
					"sInfoThousands":  ",",
					"sLoadingRecords": '<div class="progress"><div class="indeterminate"></div></div>',
					"oPaginate": {
						"sFirst":    "Primero",
						"sLast":     "Último",
						"sNext":     "Siguiente",
						"sPrevious": "Anterior"
					}
				}
			});
			$('select').addClass("browser-default");
		}

		function AlertToast(message,icon,color){
			var toastHTML = '<span>'+message+'&nbsp;</span><i class="material-icons'+' '+color+'-text'+'">'+icon+'</i>';
			return M.toast({html: toastHTML, classes: 'rounded'});
		}

		function checkSave(id,check,columna){
			var query = document.getElementById("hid_query").value;
			var parametros = {
				"id" : id,
				"etapa" : columna,
				"op" : check,
				"query" : query
			};

			var $envio = $.ajax({
				url: '../database/process_plan.php',
				data: parametros,
				type: 'POST',
			});

			$envio.success(function(){
				location.reload();
					/*$("#control-panel").load(" #control-panel");
					mostrarData();
					AlertToast("Actualizado!","done","green");*/
				});
		}

		function OcultaFecha(){
			document.getElementById("fecha").disabled = true;
		}

		function OcultaEtapa(){
			document.getElementById("selectEtapa").disabled = true;
		}

		function detalle(idPlan){
			console.log(idPlan);
			
			var parametros = {
				"id" : idPlan
			};

			var $envio = $.ajax({
				url: '../database/process_detalle.php',
				data: parametros,
				type: 'POST',
				dataType: 'json'
			});

			$envio.success(function(data){
				document.getElementById("contentModal").innerHTML="";
				var contenido =
				"<p><b>DETALLE DE ACCESORIOS</b></p>"+
				"<p>Orden: "+data.ordendesc+"</p>"+
				"<p>Estilo: "+data.estilo+"</p>"+
				"<table>"+
					"<thead>"
						+"<th>Fajas</th>"
						+"<th>RodillosPKS</th>"
						+"<th>Troqueles</th>"
						+"<th>Clishes</th>"
						+"<th>Hebillas</th>"
						+"<th>Hangers</th>"
						+"<th>Pasadores</th>"
						+"<th>Tickets</th>"
					+"</thead>"
					
					+'<tbody class="table responsive-table striped highlight" style="font-size: 12px;">'
						+"<td>Fajas</td>"
						+"<td>RodillosPKS</td>"
						+"<td>Troqueles</td>"
						+"<td>Clishes</td>"
						+"<td>Hebillas</td>"
						+"<td>Hangers</td>"
						+"<td>Pasadores</td>"
						+"<td>Tickets</td>"
					+"</tbody>"

				+"</table>"
					
				$(contenido).appendTo("#contentModal");
			});
		}

		</script>
	</body>
	</html>

