<!DOCTYPE html>
<html>
<head>
	<title></title>


	<style type="text/css">
		input[type="checkbox"]{
			display: none;
		}

		input[type="checkbox"] + label{ /*CUANDO SEA NULO EN BD = N*/
			display: inline-block;
			height: 30px;
			width: 30px;
			border-radius: 5px;
			background-color: red;
		}

		input[type="checkbox"]:indeterminate + label{ /*CUANDO SEA PENDIENTE EN BD = P*/
			background-color: yellow;
		}

		input[type="checkbox"]:checked + label{ /*CUANDO SEA CONFIRMADO EN BD = Y*/
			background-color: green;
		}
	</style>
</head>

<body>

<input id="checkbox" data-numero="0" data-actual="0" type="checkbox" onchange="comprueboCheck();" />
<label for="checkbox"></label>
<div id="estado">Estado: En proceso</div>

<script type="text/javascript">
	
	var checkbox = document.getElementById('checkbox');
	var texto = document.getElementById('estado');

	function comprueboCheck(){

		switch(checkbox.dataset.numero){
			case "0":
			checkbox.dataset.numero = "1";
			checkbox.checked = false;
			checkbox.indeterminate = true;
			texto.innerHTML = 'Estado: Despachado';
			break;

			case "1":
			checkbox.dataset.numero = "2";
			checkbox.indeterminate = false;
			checkbox.checked = true;

			texto.innerHTML = 'Estado: Recibido';
			break;
			
			case "2":
			checkbox.indeterminate = false;
			checkbox.checked = false;
			checkbox.dataset.numero = "0";
			texto.innerHTML = 'Estado: En proceso';
			break;
		}
	}

</script>

</body>
</html>