<!--
Proyecto:CONTROL PLAN DE PRODUCCION
Descripción: 
Autor: Josué Saravia - jsaravia@tata.com.gt
Fecha Inicio: 31-08-2018
-->

<?php

/*require("../login/seguridad.php");
$userRol = $_SESSION["RolUser"];
$userSes = $_SESSION["iduser"];
$userRol = $_SESSION["RolAcceso"];*/
require("../database/conn.php");
mysqli_set_charset($mysqli, "utf8");

?>

<!DOCTYPE html>
<html>
<head>
	<link type="text/css" rel="stylesheet" href="../materialize/css/icons/icons.css"><!--Import Google Icon Font-->
	<link rel="stylesheet" href="../materialize/css/materialize.min.css"><!--Import materialize.css-->
	<link rel="stylesheet" href="../js/jquery.dataTables.min.css"><!-- Pluggin de jquery para tablas dinamicas  dataTables-->
	<link rel="stylesheet" type="text/css" href="../materialize/css/estilos.css"><!-- Estilos personalizados -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/><!--Let browser know website is optimized for mobile-->
	<meta charset="utf-8"><!-- Codificación para español -->
	<title>PLAN DE PRODUCCION</title>
	<link rel="icon" href="../images/logo/calendar1.png" sizes="30x30">

	<style type="text/css">
	@media only screen and (min-width: 600px) {
		#linea {
			margin-left: 75px;
		}
	}
	@media only screen and (max-width: 600px) {
		#linea {
			margin-left: 10px;
			width: 300px;
		}
	}

	.cent {
		text-align: center;
	}
</style>

</head>

<body>

	<?php include("menu_nav.php"); ?>

	<br><br>

	<main>

		<?php //if ($userRol == 1) { ?>
			<?php //} ?>

			<div class="left-align">
				<div class="col s12 m12">
					<div class="row" id="linea">
						<select id="selectLinea" class="col s12 m2" style="margin-right: 50px;">
							<option selected="selected" value="0">Línea/Area</option>
							<option value="1">Ensamble 1</option>
							<option value="2">Ensamble 2</option>
							<option value="3">Ensamble 3</option>
							<option value="4">Ensamble 4</option>
							<option value="5">Ensamble 5</option>
							<option value="6">Ensamble 6</option>
							<option value="7">Ensamble 7</option>
						</select>

						<input class="col s12 m2" type="date" name="" style="margin-right: 50px;">
						
						<!--
						<div class="col s12 m3">
							<p><b>Línea: </b>30001 ENSAMBLE FELTH 1</p>
						</div>
						<div class="col s12 m3">
							<p><b>Fecha: </b>31 de Agosto 2018</p>
						</div>
					-->
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col s11" id="table">
				<div class="divider"></div>
				<table id="TableData" class="table responsive-table striped highlight" style="font-size: 12px;">
					<thead>
						<tr>
							<th></th>
							<th>No.</th>
							<th>Orden</th>
							<th>Estilo</th>
							<th>Cliente</th>
							<th>Inicio Prod</th>
							<th>T. Plan</th>
							<th>F. Listas</th>
							<th>Fajas </th>
							<th>Rodillos PKS</th>
							<th>Troqueles</th>
							<th>Clishes</th>
							<th>Hebillas</th>
							<th>Hangers</th>
							<th>Pasadores</th>
							<th>Tickets</th>
							<th>%Preparacion</th>
						</tr>
					</thead>
					<tbody>

						<?php 
						$query = mysqli_query($mysqli,"SELECT * FROM PP_semanal;")
						or die('error: '.mysqli_error($mysqli));

						while ($row = mysqli_fetch_assoc($query)) {
							$id = $row["Id_plan"];
							?>
							<tr>
								<td class="tooltipped" data-position="top" data-tooltip="Detalles de la orden"><a class="material-icons black-text modal-trigger" href="#info_estilo" style="cursor: pointer;"><i class="material-icons">add_circle</i></a></td>
								<td class="cent"><?php print $id; ?></td>
								<td><?php print $row["Orden"]; ?></td>
								<td><?php print $row["Estilo"]; ?></td>
								<td><?php print $row["Cliente"]; ?></td>
								<td><?php print $row["InicioProd"]; ?></td>
								<td class="cent"><?php print $row["TotalPlan"]; ?></td>
								<td class="cent"><?php print $row["FajasListas"]; ?></td>

								<!-- FAJAS -->
								<td class="cent">
									<?php if ($row["Fajas"] == "Y") { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Fajas',this.checked);" type="checkbox" checked="checked" />
											<span></span>
										</label>	
									<?php } else { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Fajas',this.checked);" type="checkbox" />
											<span></span>
										</label>
									<?php } ?>
								</td>

								<!-- Rodillos -->
								<td class="cent">
									<?php if ($row["Rodillos"] == "Y") { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Rodillos',this.checked);" type="checkbox" checked="checked" />
											<span></span>
										</label>	
									<?php } else { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Rodillos',this.checked);" type="checkbox" />
											<span></span>
										</label>
									<?php } ?>
								</td>

								<!-- Troqueles -->
								<td class="cent">
									<?php if ($row["Troqueles"] == "Y") { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Troqueles',this.checked);" type="checkbox" checked="checked" />
											<span></span>
										</label>	
									<?php } else { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Troqueles',this.checked);" type="checkbox" />
											<span></span>
										</label>
									<?php } ?>
								</td>

								<!-- Clishes -->
								<td class="cent">
									<?php if ($row["Clishes"] == "Y") { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Clishes',this.checked);" type="checkbox" checked="checked" />
											<span></span>
										</label>	
									<?php } else { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Clishes',this.checked);" type="checkbox" />
											<span></span>
										</label>
									<?php } ?>
								</td>

								<!-- Hebillas -->
								<td class="cent">
									<?php if ($row["Hebillas"] == "Y") { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Hebillas',this.checked);" type="checkbox" checked="checked" />
											<span></span>
										</label>	
									<?php } else { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Hebillas',this.checked);" type="checkbox" />
											<span></span>
										</label>
									<?php } ?>
								</td>

								<!-- Hangers -->
								<td class="cent">
									<?php if ($row["Hangers"] == "Y") { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Hangers',this.checked);" type="checkbox" checked="checked" />
											<span></span>
										</label>	
									<?php } else { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Hangers',this.checked);" type="checkbox" />
											<span></span>
										</label>
									<?php } ?>
								</td>

								<!-- Pasadores -->
								<td class="cent">
									<?php if ($row["Pasadores"] == "Y") { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Pasadores',this.checked);" type="checkbox" checked="checked" />
											<span></span>
										</label>	
									<?php } else { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Pasadores',this.checked);" type="checkbox" />
											<span></span>
										</label>
									<?php } ?>
								</td>

								<!-- Tickets -->
								<td class="cent">
									<?php if ($row["Tickets"] == "Y") { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Tickets',this.checked);" type="checkbox" checked="checked" />
											<span></span>
										</label>	
									<?php } else { ?>
										<label>
											<input id="" onclick="checkSave(<?php print $id; ?>,'Tickets',this.checked);" type="checkbox" />
											<span></span>
										</label>
									<?php } ?>
								</td>

								<td class="cent" style="font-size: 18px;"><b>100%</b></td>

							<!--<td style="cursor: pointer;" onclick="EditReport(<?php// echo $row["Id"]; ?>)"><i class="material-icons grey-text">edit</i></td>
								<td style="cursor: pointer;" onclick="DeleteReport(<?php //echo $row["Id"]; ?>)"><i class="material-icons grey-text">delete</i></td>-->

							</tr>
						<?php } ?>
						<tr style="font-size: 18px;">
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td class="cent"><b>15%</b></td>
							<td class="cent"><b>50%</b></td>
							<td class="cent"><b>50%</b></td>
							<td class="cent"><b>100%</b></td>
							<td class="cent"><b>100%</b></td>
							<td class="cent"><b>50%</b></td>
							<td class="cent"><b>75%</b></td>
							<td class="cent"><b>50%</b></td>
							<td class="cent"><b>100%</b></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</main>

	<div id="info_estilo" class="modal" style="max-width: 70%;">
		<div class="modal-content">
			<p id="pruebaJS"></p>
			<h4>Información del estilo 54836: </h4>
			<p>Datos</p>
		</div>
		<div class="modal-footer">
			<a href="#!" id="" class="modal-action modal-close waves-effect waves-green btn-flat">Aceptar</a>
			<a class="modal-action modal-close waves-effect waves-red btn-flat">Cancelar</a>
		</div>
	</div>

	<script src="../js/jquery-2.1.1.min.js"></script><!--Import jQuery before materialize.js-->
	<script src="../js/materialize.min.js"></script><!-- Importar funciones de materialize css -->
	<script src="../js/jquery.dataTables.min.js"></script><!-- pluggin de jquery para hacer tablas dinámicas -->
	<script src="../js/materializeEffects.js"></script><!-- Funciones de jquery que necesita materializecss -->

	<script>
		$(document).on("ready", function(){
			mostrarData();
		});

		var mostrarData = function(){
			var table = $('#TableData').DataTable({
				"destroy":true,
				"bPaginate": true,
				"bSort": false,
		        //"aoColumnDefs": [ { 'bSortable': false, 'aTargets': [ 2,4,5,8,9,10 ] } ],
		        "bJQueryUI": false,
		        "lengthMenu": [[5, 8, 10, 15, 20, 25, 50, -1], [5, 8, 10, 15, 20, 25, 50, "Todos"]],
		        "iDisplayLength": -1,
		        "bProcessing": false,
		        "language": {
		        	"sProcessing":     '<div class="progress"><div class="indeterminate"></div></div>',
		        	"sLengthMenu":     "&nbsp; Mostrar _MENU_ <br>",
		        	"sZeroRecords":    "No se encontraron datos",
		        	"sEmptyTable":     "Ningún dato disponible en esta tabla",
		        	"sInfo":           "Mostrando datos del _START_ al _END_ de un total de _TOTAL_",
		        	"sInfoEmpty":      "Mostrando datos del 0 al 0 de un total de 0",
		        	"sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
		        	"sInfoPostFix":    "",
		        	"sSearch":         "<br>",
		        	"sSearchPlaceholder": " BUSCAR EN EL PLAN",
		        	"sUrl":            "",
		        	"sInfoThousands":  ",",
		        	"sLoadingRecords": '<div class="progress"><div class="indeterminate"></div></div>',
		        	"oPaginate": {
		        		"sFirst":    "Primero",
		        		"sLast":     "Último",
		        		"sNext":     "Siguiente",
		        		"sPrevious": "Anterior"
		        	}
		        }
		    });
			$('select').addClass("browser-default");
		}

		function AlertToast(message,icon,color){
			var toastHTML = '<span>'+message+'&nbsp;</span><i class="material-icons'+' '+color+'-text'+'">'+icon+'</i>';
			return M.toast({html: toastHTML, classes: 'rounded'});
		}

		function checkSave(id,etapa,check){

		//AlertToast('Cambio de estado! Id: '+id+' Etapa:'+etapa+' check: '+check,'done','green');

			var parametros = {
				"id" : id,
				"etapa" : etapa,
				"op" : check
			};

			var $envio = $.ajax({
				url: '../database/process_plan.php',
				data: parametros,
				type: 'POST',
			});

			$envio.success(function(){
				AlertToast('Cambio de estado! Id: '+id+' Etapa:'+etapa+' check: '+check,'done','green');
			});
		}


		function DeleteReport(id){
			console.log(id);
			var op = confirm("¿Desea eliminar el reporte seleccionado?");
			if (op == true) {
				var parametros = {
					"id" : id,
					"op" : "delete"
				};

				var $envio = $.ajax({
					url: '../database/process_report.php',
					data: parametros,
					type: 'POST',
				});

				$envio.success(function(){
					location.reload();
					AlertToast('Eliminado!','delete','green');
				});
			}
		}

		function EditReport(id){
			$("#opcion").val("update");
			$("#id_update").val(id);
			var parametros = {
				"id" : id,
				"op" : "select"
			};

			var $envio = $.ajax({
				url: '../database/process_report.php',
				data: parametros,
				type: 'POST',
				dataType: 'json'
			});

			$envio.success(function(data){
				opcion = $("#opcion").val("update");
				id = data.id;
				nombre = $("#nombre").val(data.nombre).focus();
				desc = $("#descripcion").val(data.desc).focus();
				area = $("#area").val(data.area).focus();
				resp = $("#responsable").val(data.resp).focus();
				img = $("#img_rep").val(data.img).focus();
				link = $("#linkRep").val(data.linkRep).focus();
				ubic = $("#ubRep").val(data.ubica).focus();

				nombre.focus();
			});
		}

		function repAccess(select,idRep){
			var usuario = select.options[select.selectedIndex];
			usr = usuario.value;
			console.log(usr+"-"+idRep);

			var parametros = {
				"id" : usr,
				"idRep" : idRep,
				"op" : "AddRep"
			};
			var $envio = $.ajax({
				url: '../database/process_user.php',
				data: parametros,
				type: 'POST',
				dataType : 'json'
			});
			$envio.success(function(data){
				if (data.reporte =="OK") {
					AlertToast('Nuevo reporte agregado!','done','green');	
				} else if (data.reporte == "existente") {
					AlertToast('El usuario ya tiene acceso a este reporte!','cancel','red');	
				}

			});
		}

	</script>

</body>
</html>