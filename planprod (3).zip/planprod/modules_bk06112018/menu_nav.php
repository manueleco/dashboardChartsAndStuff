<!--
Proyecto:CONTROL PLAN DE PRODUCCION
Descripción: 
Autor: Josué Saravia - jsaravia@tata.com.gt
Fecha Inicio: 31-08-2018
-->

<?php 
	require("../login/seguridad.php");
	$userRol = $_SESSION["RolUser"];
	$usrName = $_SESSION["nombreAD"];
	$usrMail = $_SESSION["correoAD"];
?>

<!DOCTYPE html>
<html>

<head>
	<link type="text/css" rel="stylesheet" href="../materialize/css/icons/icons.css"><!--Import Google Icon Font-->
	<link rel="stylesheet" href="../materialize/css/materialize.min.css"><!--Import materialize.css-->
	<link rel="stylesheet" href="../js/jquery.dataTables.min.css"><!-- Pluggin de jquery para tablas dinamicas  dataTables-->
	<link rel="stylesheet" type="text/css" href="../materialize/css/estilos.css"><!-- Estilos personalizados -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/><!--Let browser know website is optimized for mobile-->
	<meta charset="utf-8"><!-- Codificación para español -->
	<title>PLAN DE PRODUCCION</title>
    <link rel="icon" href="../images/logo/calendar1.png" sizes="30x30">
</head>
	
<body>
	<header>

		<?php 
		//USUARIO ADMINISTRADOR
		if ($userRol == 1) { ?>

			<!-- <a href="#" data-target="slide-out" class="sidenav-trigger btn-floating grey hoverable" style="position: absolute; margin-top: 12px; margin-left: 5px; z-index: 1;"><i class="material-icons">menu</i></a> -->

			<div class="navbar-fixed">
			  <nav class="grey darken-1">
			    <div class="nav-wrapper">
			    	
			      <a href="table-admin.php" class="brand-logo">&nbsp;TATA</a>
			      <a href="" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
			      <ul class="right hide-on-med-and-down">
			        <li><a href="table-admin.php"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
			        <li><a href="reporte_tiempo.php"><i class="material-icons left white-text">book</i>Informe</a></li>
			        <li><a href="admin_areas.php"><i class="material-icons left white-text">donut_large</i>Etapas</a></li>
			        <li><a href="admin_roles.php"><i class="material-icons left white-text">lock</i>Permisos</a></li>
			        <li><a href="admin_usuarios.php"><i class="material-icons left white-text">person</i>Usuarios</a></li>
			        <li class="tooltipped" data-position="left" data-tooltip="Notificaciones"><a href="notificaciones.php"><i class="material-icons center white-text">notifications</i></a></li>
			        <li class="tooltipped" data-position="left" data-tooltip="Ayuda"><a href="notificaciones.php"><i class="material-icons center white-text">help</i></a></li>
			        <li class="tooltipped" data-position="left" data-tooltip="Salir"><a href="../login/salir.php"><i class="material-icons center white-text">power_settings_new</i></a></li>
			      </ul>
			    </div>
			  </nav>
		  	</div>

		    <ul class="sidenav" id="mobile-demo">
			   <li><a href="table-admin.php"><i class="material-icons left black-text">event_note</i>Control - Ensamble</a></li>
			   <li><a href="reporte_tiempo.php"><i class="material-icons left black-text">book</i>Informe</a></li>
			   <li><a href="admin_areas.php"><i class="material-icons left black-text">donut_large</i>Etapas</a></li>
			   <li><a href="admin_roles.php"><i class="material-icons left black-text">lock</i>Permisos</a></li>
			   <li><a href="admin_usuarios.php"><i class="material-icons left black-text">person</i>Usuarios</a></li>
			   <li><a href="notificaciones.php"><i class="material-icons center red-text">notifications</i></a></li>
			   <li><a href="notificaciones.php"><i class="material-icons center red-text">help</i></a></li>
			   <li><a href="../login/salir.php"><i class="material-icons center red-text">power_settings_new</i></a></li>
		    </ul>


		    <!--<a href="#" data-target="slide-out" class="sidenav-trigger btn-floating grey"><i class="material-icons">menu</i></a>-->
			
			<!-- <ul id="slide-out" class="sidenav">
				<li>
					<div class="user-view">
					<a href="#name"><span class="name"><?php //echo $usrName; ?></span></a>
					<a href="#email"><span class="email"><?php //echo $usrMail; ?></span></a>
					</div>
				</li>
				<li><div class="divider"></div></li>
				<li><a class="waves-effect" href="table-admin.php"><i class="material-icons left black-text">event_note</i>Control - Ensamble</a></li>
				<li><a class="waves-effect" href="reporte_tiempo.php"><i class="material-icons left black-text">book</i>Informe</a></li>
				<li><a class="waves-effect" href="admin_areas.php"><i class="material-icons left black-text">donut_large</i>Áreas proveedoras</a></li>
				<li><a class="waves-effect" href="admin_roles.php"><i class="material-icons left black-text">lock</i>Roles y permisos</a></li>
				<li><a class="waves-effect" href="admin_usuarios.php"><i class="material-icons left black-text">person</i>Usuarios</a></li>
				<li><a class="waves-effect" style="color: black;" href="../login/salir.php"><i class="material-icons left black-text">exit_to_app</i>Salir</a></li>
			</ul> -->
			

		<?php } 

		//USUARIO PLANIFICACION
		else if ($userRol == 2) { ?>

			<div class="navbar-fixed">
			  <nav class="grey darken-2" style="">
			    <div class="nav-wrapper">
			      <a href="table-admin.php" class="brand-logo">TATA</a>
			      <a href="" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
			      <ul class="right hide-on-med-and-down">
			        <li><a href="table-admin.php"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
			        <li><a href="reporte_tiempo.php"><i class="material-icons left white-text">book</i>Informe</a></li>
			        <li><a style="color: red;" href="../login/salir.php"><i class="material-icons left red-text">exit_to_app</i>Salir</a></li>
			      </ul>
			    </div>
			  </nav>
		  	</div>

		    <ul class="sidenav" id="mobile-demo">
			   <li><a href="table-admin.php"><i class="material-icons left black-text">event_note</i>Control - Ensamble</a></li>
			   <li><a href="reporte_tiempo.php"><i class="material-icons left black-text">book</i>Informe</a></li>
			   <li><a style="color: red;" href="../login/salir.php"><i class="material-icons left red-text">exit_to_app</i>Salir</a></li>
		    </ul>

		<?php }

		//USUARIO GERENTE DE PRODUCCION
		else if ($userRol == 3) { ?>

			<div class="navbar-fixed">
			  <nav class="grey darken-2" style="">
			    <div class="nav-wrapper">
			      <a href="table-admin.php" class="brand-logo">TATA</a>
			      <a href="" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
			      <ul class="right hide-on-med-and-down">
			        <li><a href="table-admin.php"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
			        <li><a href="reporte_tiempo.php"><i class="material-icons left white-text">book</i>Informe</a></li>
			        <li><a style="color: red;" href="../login/salir.php"><i class="material-icons left red-text">exit_to_app</i>Salir</a></li>
			      </ul>
			    </div>
			  </nav>
		  	</div>

		    <ul class="sidenav" id="mobile-demo">
			   <li><a href="table-admin.php"><i class="material-icons left black-text">event_note</i>Control - Ensamble</a></li>
			   <li><a href="reporte_tiempo.php"><i class="material-icons left black-text">book</i>Informe</a></li>
			   <li><a style="color: red;" href="../login/salir.php"><i class="material-icons left red-text">exit_to_app</i>Salir</a></li>
		    </ul>

		<?php } 

		//USUARIO JEFE DE LINEA
		else if ($userRol == 4) { ?>

			<div class="navbar-fixed">
			  <nav class="grey darken-2" style="">
			    <div class="nav-wrapper">
			      <a href="table-admin.php" class="brand-logo">TATA</a>
			      <a href="" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
			      <ul class="right hide-on-med-and-down">
			        <li><a href="table-admin.php"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
			        <li><a style="color: red;" href="../login/salir.php"><i class="material-icons left red-text">exit_to_app</i>Salir</a></li>
			      </ul>
			    </div>
			  </nav>
		  	</div>

		    <ul class="sidenav" id="mobile-demo">
			   <li><a href="table-admin.php"><i class="material-icons left black-text">event_note</i>Control - Ensamble</a></li>
			   <li><a style="color: red;" href="../login/salir.php"><i class="material-icons left red-text">exit_to_app</i>Salir</a></li>
		    </ul>

		<?php } 
		//USUARIOS DE BODEGAS
		else { ?>

			<div class="navbar-fixed">
			  <nav class="grey darken-2" style="">
			    <div class="nav-wrapper">
			      <a href="table-admin.php" class="brand-logo">TATA</a>
			      <a href="" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
			      <ul class="right hide-on-med-and-down">
			        <li><a href="table-admin.php"><i class="material-icons left white-text">event_note</i>Control - Ensamble</a></li>
			        <li><a style="color: red;" href="../login/salir.php"><i class="material-icons left red-text">exit_to_app</i>Salir</a></li>
			      </ul>
			    </div>
			  </nav>
		  	</div>

		    <ul class="sidenav" id="mobile-demo">
			   <li><a href="table-admin.php"><i class="material-icons left black-text">event_note</i>Control - Ensamble</a></li>
			   <li><a style="color: red;" href="../login/salir.php"><i class="material-icons left red-text">exit_to_app</i>Salir</a></li>
		    </ul>

		<?php } ?>

	</header>

	<script src="../js/jquery-2.1.1.min.js"></script><!--Import jQuery before materialize.js-->
	<script src="../js/materialize.min.js"></script><!-- Importar funciones de materialize css -->
	<script src="../js/jquery.dataTables.min.js"></script><!-- pluggin de jquery para hacer tablas dinámicas -->
	<script src="../js/materializeEffects.js"></script><!-- Funciones de jquery que necesita materializecss -->
	<script src="../push.js-master/bin/push.js"></script> <!-- NOTIFICACIONES -->
</body>
</html>