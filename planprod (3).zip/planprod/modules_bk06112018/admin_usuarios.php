<!--
Proyecto:CONTROL PLAN DE PRODUCCION
Descripción: 
Autor: Josué Saravia - jsaravia@tata.com.gt
Fecha Inicio: 31-08-2018
-->

<?php 
	require("../login/seguridad.php");
	//$user = $_GET["name"];
?>

<!DOCTYPE html>
<html>

<body>

	<?php include("menu_nav.php"); ?>
		
	<main>
		<div class="row">
			<div class="col s11" id="table">

				<div class="left">
					<br>
					<a class="material-icons black-text modal-trigger left" href="#mod_logs"><i style="font-size: 1.5em;" class="material-icons green-text tooltipped" data-position="right" data-tooltip="Log de accesos">person</i></a>&nbsp;
					<br><br>
				</div>

				<table id="TableData" class="table responsive-table striped highlight">
					<thead>
						<tr>
							<th>ID</th>
							<th>Usuario AD</th>
							<th>Fecha Solicitud</th>
							<th>Rol de Acceso</th>
							<th>Estado</th>
							<th></th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php require('../database/conn.php');

						header('Content-Type: text/html; charset=UTF-8');
						mysqli_set_charset($mysqli, "utf8");

						$query = mysqli_query($mysqli,"SELECT U.ID, U.USRNOMBRE, U.CORREO, U.ESTADOSOLICITUD, U.FECHASOLICITUD, R.ID AS IDROL, R.ROLNOMBRE,
							CASE WHEN U.ESTADOSOLICITUD ='P' THEN 'Inactivo' ELSE 'Activo' END AS ESTADOSOLICITUD
							FROM PP_USUARIO U
							LEFT JOIN PP_ROL R ON R.ID = U.ROLACCESO
							ORDER BY ID DESC;")
							or die('error: '.mysqli_error($mysqli)); ?>

							<?php while ($row = mysqli_fetch_assoc($query)) { ?>
								<tr>
									<td><?php print $row["ID"]; ?></td>
									<td><?php print $row["USRNOMBRE"]; ?></td>
									<!-- <td><?php //print $row["Correo"]; ?></td>-->
									<td><?php print $row["FECHASOLICITUD"]; ?></td>

									<?php $query1 = mysqli_query($mysqli,"SELECT * FROM PP_ROL WHERE ACTIVO = 'Y' ORDER BY ID;")
									or die('error: '.mysqli_error($mysqli)); ?>
									<td>
										<select style="height: 25px; width: 150px; margin-right: 75px;" onchange="rolSave(<?php print $row["ID"]; ?>,this.selectedIndex);">
											<option selected="selected" value="<?php print $row["ID"]; ?>"><?php print $row["ROLNOMBRE"]; ?></option>											
											<?php
											while ($raw = mysqli_fetch_assoc($query1)) { ?>
												<option value="<?php print $raw["ID"]; ?>"><?php print $raw["ROLNOMBRE"]; ?></option>
											<?php } ?>
										</select>
									</td>
									<td><?php print $row["ESTADOSOLICITUD"]; ?></td>

									<?php if ($row["ESTADOSOLICITUD"] == "Inactivo") { ?>
										<td style="cursor: pointer;" onclick="AceptarAcceso(<?php echo $row["ID"]; ?>)"><i class="material-icons red-text tooltipped" data-position="right" data-tooltip="¿Confirmar usuario?">lock</i></td>	
									<?php } else  { ?>
										<td style="cursor: pointer;" onclick="InactivarAcceso(<?php echo $row["ID"]; ?>)"><i class="material-icons green-text tooltipped" data-position="right" data-tooltip="¿Desactivar usuario?">done</i></td>	
									<?php } ?>
									<td class="tooltipped" data-position="left" data-tooltip="¿Eliminar usuario?" style="cursor: pointer;" onclick="DeleteUser(<?php echo $row["ID"]; ?>)"><i class="material-icons grey-text">delete</i></td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</main>

		<!-- MODALES -->
		<div id="mod_logs" class="modal" style="max-width: 70%;">
			<div class="modal-content">
				<table id="TableData" class="table responsive-table striped highlight">
					<thead>
						<tr>
							<th>NO.</th>
							<th>USUARIO</th>
							<th>NOMBRE</th>
							<th>CORREO</th>
							<th>ROL</th>
							<th>ÚLTIMO ACCESO</th>
						</tr>
					</thead>
					<tbody>
					<?php require('../database/conn.php');

					header('Content-Type: text/html; charset=UTF-8');
					mysqli_set_charset($mysqli, "utf8");

					$query = mysqli_query($mysqli,"SELECT ULOG.IDLOG, ULOG.USUARIO, ULOG.NOMBRE, ULOG.CORREO, ULOG.ROL, ULOG.ULTIM_ACCESO FROM PP_ULOG ULOG ORDER BY ULOG.ULTIM_ACCESO DESC;")
					or die('error: '.mysqli_error($mysqli)); ?>

					<?php while ($row = mysqli_fetch_assoc($query)) { ?>
						<tr>
							<td><?php print $row["IDLOG"]; ?></td>
							<td><?php print $row["USUARIO"]; ?></td>
							<td><?php print $row["NOMBRE"]; ?></td>
							<td><?php print $row["CORREO"]; ?></td>
							<td><?php print $row["ROL"]; ?></td>
							<td><?php print $row["ULTIM_ACCESO"]; ?></td>
						</tr>
					<?php } ?>

					</tbody>
				</table>

			</div>
			<div class="modal-footer">
				<a class="modal-action modal-close waves-effect waves-green btn-flat">OK</a>
			</div>
		</div>
		<!-- FIN MODALES -->

		<script src="../js/jquery-2.1.1.min.js"></script><!--Import jQuery before materialize.js-->
		<script src="../js/materialize.min.js"></script><!-- Importar funciones de materialize css -->
		<script src="../js/jquery.dataTables.min.js"></script><!-- pluggin de jquery para hacer tablas dinámicas -->
		<script src="../js/admin_usuarios.js"></script>
		<script src="../js/materializeEffects.js"></script><!-- Funciones de jquery que necesita materializecss -->

    <script type="text/javascript">
    	$(document).on("ready", function(){
    		mostrarData();
    	});

    	var mostrarData = function(){
    		var table = $('#TableData').DataTable({
    			"destroy":true,
    			"bPaginate": true,
    			"bSort": true,
	        //"aoColumnDefs": [ { 'bSortable': false, 'aTargets': [ 2,4,5,8,9,10 ] } ],
	        "bJQueryUI": false,
	        "lengthMenu": [[5, 8, 10, 20, 25, 50, -1], [5, 8, 10, 20, 25, 50, "Todos"]],
	        "iDisplayLength": -1,
	        "bProcessing": false,
	        "language": {
	        	"sProcessing":     '<div class="progress"><div class="indeterminate"></div></div>',
	        	"sLengthMenu":     "Mostrar _MENU_ <br>",
	        	"sZeroRecords":    "No se encontraron datos",
	        	"sEmptyTable":     "Ningún dato disponible en esta tabla",
	        	"sInfo":           "Mostrando datos del _START_ al _END_ de un total de _TOTAL_",
	        	"sInfoEmpty":      "Mostrando datos del 0 al 0 de un total de 0",
	        	"sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
	        	"sInfoPostFix":    "",
	        	"sSearch":         "<br>",
	        	"sSearchPlaceholder": " Buscar reporte",
	        	"sUrl":            "",
	        	"sInfoThousands":  ",",
	        	"sLoadingRecords": '<div class="progress"><div class="indeterminate"></div></div>',
	        	"oPaginate": {
	        		"sFirst":    "Primero",
	        		"sLast":     "Último",
	        		"sNext":     "Siguiente",
	        		"sPrevious": "Anterior"
	        	}
	        }
	    });
    		$('select').addClass("browser-default");
    	}

    	function AlertToast(message,icon,color){
    		var toastHTML = '<span>'+message+'&nbsp;</span><i class="material-icons'+' '+color+'-text'+'">'+icon+'</i>';
    		return M.toast({html: toastHTML, classes: 'rounded'});
    	}

    	function DeleteUser(id){
    		console.log(id);
    		var op = confirm("¿Desea eliminar el usuario seleccionado?");
    		if (op == true) {
    			var parametros = {
    				"id" : id,
    				"op" : "delete"
    			};
    			var $envio = $.ajax({
    				url: '../database/process_user.php',
    				data: parametros,
    				type: 'POST'
    			});
    			$envio.success(function(){
    				location.reload();
    				AlertToast('Eliminado!','delete','green');
    			});
    		}
    	}

    	function AceptarAcceso(id){
    		var parametros = {
    			"id" : id,
    			"op" : "update",
    			"acceso" : "A"
    		};
    		var $envio = $.ajax({
    			url: '../database/process_user.php',
    			data: parametros,
    			type: 'POST'
    		});
    		$envio.success(function(){
    			//M.toast({html: 'activado', completeCallback: function(){location.reload();}});
    			location.reload();
    		});
    	}

    	function InactivarAcceso(id){
    		var parametros = {
    			"id" : id,
    			"op" : "update",
    			"acceso" : "P"
    		};
    		var $envio = $.ajax({
    			url: '../database/process_user.php',
    			data: parametros,
    			type: 'POST'
    		});
    		$envio.success(function(){
    			//M.toast({html: 'desactivado', timeRemaining:1, completeCallback: function(){location.reload();}});
    			location.reload();
    		});
    	}

    	function rolSave(idUsuario,item){
    		rol = item;
    		usr = idUsuario;

			var parametros = {
				"id" : usr,
				"rol": rol,
				"op" : "AddPrivs"
			};
			var $envio = $.ajax({
				url: '../database/process_user.php',
				data: parametros,
				type: 'POST',
				dataType : 'json'
			});
			$envio.success(function(data){
				AlertToast('Nuevo rol agregado!','done','green');
			});
		}


</script>


</body>
</html>