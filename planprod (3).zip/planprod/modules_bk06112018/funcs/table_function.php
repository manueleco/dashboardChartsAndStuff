<?php

function BuildTable($query, $colNum, $flag){

	//Indica la posición a partir de la cual mostrará columnas con checks
	$colsInfo = 8;

	require("../database/conn.php");
	mysqli_set_charset($mysqli, "utf8");

	$conexion = mysqli_connect($serverDWH,$userDWH,$passDWH,$bdDWH);
	if(!$result = mysqli_query($conexion, $query)) die(); //generamos la consulta
	$rawdata = array(); //guardamos en un array multidimensional todos los datos de la consulta
	 
	$i=0;
	while($row = mysqli_fetch_array($result)) {
		$rawdata[$i] = $row;
		$i++;
	}

	$close = mysqli_close($conexion);

	//TABLA Dibujamos la tabla con las propiedades para materialize y jquery
	echo '<table id="TableData" class="table responsive-table striped highlight" style="font-size: 11px;">';
	$columnas = count($rawdata[0])/2;
	$filas = count($rawdata);
	
	//Añadimos encabezado y los titulos
	echo "<thead>";
		echo "<tr>";

			for($i=0; $i<count($rawdata[0]); $i+=2){
				next($rawdata[0]);
				$col = key($rawdata[0]);
				echo '<th class="cent">'.$col.'</th>';
				next($rawdata[0]);
			}

			echo '<th class="cent">ESTADO</th>';
			//echo "<th>DETALLES</th>";
		echo "</tr>";
	echo "</thead>";

	echo '<tbody>';
	//FILAS DE LA TABLA
	for($i=0; $i<$filas; $i++){

		$rojos = 0;
		$amarillos = 0;
		$verdes = 0;
		echo "<tr>";
			
		//COLUMNAS DE INFORMACIÓN ENCABEZADO (Orden, estilo, cliente, etc)
		for($j=0; $j<$colsInfo; $j++){
			$id = $rawdata[$i][0];
			echo '<td class="cent">'.$rawdata[$i][$j].'</td>';
		}

		//COLUMNAS CON CHECKS PARA ETAPAS DEPENDIENDO DEL ESTADO GUARDADO
		for($j=$colsInfo; $j<$columnas; $j++) {

			if($rawdata[$i][$j] == "N") {

				if ($flag == 0) {
					$estado = '_disabled="disabled"';
				} else if ($flag == 1) {
					$estado = 'disabled="disabled"';
				} else if ($flag == 2) {
					$estado = '_disabled="disabled"';
				} else if ($flag == 3) {
					$estado = 'disabled="disabled"';
				}

				if ($colNum != 0) {

					echo '<td class="cent">
							<label>
								<input onclick='.'"'.'checkSave('."'".$id."'".', 0, '."'".$j."'".');'.'"'.' type="checkbox"  '.$estado.' />
								<span></span>
							</label>
						</td>';
				}

				else {
					$col = $j+1;

					$queryCols = mysqli_query($mysqli, "SELECT COLUMN_NAME AS COL FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'PP_SEMANAL' AND ORDINAL_POSITION IN ($col)") 
					or die('error cl: '.mysqli_error($mysqli));
					while ($strData = mysqli_fetch_assoc($queryCols)) {
						$column = $strData["COL"];
					}

					echo '<td class="cent">
							<label>
								<input onclick='.'"'.'checkSave('."'".$id."'".', 0, '."'".$column."'".');'.'"'.' type="checkbox"  '.$estado.' />
								<span></span>
							</label>
						</td>';

				}
				$rojos += 1;
			}

			else if ($rawdata[$i][$j] == "P") {

				if ($flag == 0) {
					$estado = '_disabled="disabled"';
				} else if ($flag == 1) {
					$estado = 'disabled="disabled"';
				} else if ($flag == 2) {
					$estado = 'disabled="disabled"';
				} else if ($flag == 3) {
					$estado = '_disabled="disabled"';
				}

				if ($colNum != 0) {

					echo '<td class="cent">
							<label>
								<input onclick='.'"'.'checkSave('."'".$id."'".', 1, '."'".$j."'".');'.'"'.' type="checkbox" checked="checked" '.$estado.' />
								<span></span>
							</label>
						</td>';
				}

				else {
					$col = $j+1;

					$queryCols = mysqli_query($mysqli, "SELECT COLUMN_NAME AS COL FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'PP_SEMANAL' AND ORDINAL_POSITION IN ($col)") 
					or die('error cl: '.mysqli_error($mysqli));
					while ($strData = mysqli_fetch_assoc($queryCols)) {				
						$column = $strData["COL"];
					}
					echo '<td class="cent">
							<label>
								<input id="red" onclick='.'"'.'checkSave('."'".$id."'".', 1, '."'".$column."'".');'.'"'.' type="checkbox" checked="checked" '.$estado.' />
								<span></span>
							</label>			
						</td>';
				}
				$amarillos += 1;
			}

			else if ($rawdata[$i][$j] == "Y") {

				if ($flag == 0) {
					$estado = '_disabled="disabled"';
				} else if ($flag == 1) {
					$estado = 'disabled="disabled"';
				} else if ($flag == 2) {
					$estado = 'disabled="disabled"';
				} else if ($flag == 3) {
					$estado = 'disabled="disabled"';
				}

				if ($colNum != 0) {
				
					echo '<td class="cent">
							<label>
								<input class="filled-in" onclick='.'"'.'checkSave('."'".$id."'".', 2, '."'".$j."'".');'.'"'.' type="checkbox" checked="checked" '.$estado.' />
								<span></span>
							</label>
						</td>';
				}

				else {
					$col = $j+1;

					$queryCols = mysqli_query($mysqli, "SELECT COLUMN_NAME AS COL FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'PP_SEMANAL' AND ORDINAL_POSITION IN ($col)") 
					or die('error: '.mysqli_error($mysqli));
					while ($strData = mysqli_fetch_assoc($queryCols)) {				
						$column = $strData["COL"];
					}
					echo '<td class="cent">
							<label>
								<input class="filled-in" onclick='.'"'.'checkSave('."'".$id."'".', 2, '."'".$column."'".');'.'"'.' type="checkbox" checked="checked"  '.$estado.' />
								<span></span>
							</label>
						</td>';
				}
				$verdes +=1;
			}
		}

		//VALIDACION SEMAFORO POR CADA FILA
		if ($rojos > 0) {
			echo '<td class="cent"><i class="material-icons red-text _red _pulse" style="font-size: 2.5rem; /*z-index: 1; border-radius: 18px;*/">remove_circle</i></td>';
		} else if ($amarillos > 0) {
			echo '<td class="cent"><i class="material-icons yellow-text " style="font-size: 2.5rem;">pause_circle_filled</i></td>';
		} else if ($verdes > 0) {
			echo '<td class="cent"><i class="material-icons green-text" style="font-size: 2.5rem;">check_circle</i></td>';
		}
			//DETALLE DE ORDEN/ESTILO
			//echo '<td><center><a class="material-icons black-text modal-trigger" href="#info_estilo" onclick="detalle('."'".$id."'".');"><i style="font-size: 2.5rem; "class="material-icons">add_circle</i></a></center></td>';

		echo "</tr>";
	}

	echo "</tbody>";
	echo "</table>";
}

	mysqli_close($mysqli);

?>