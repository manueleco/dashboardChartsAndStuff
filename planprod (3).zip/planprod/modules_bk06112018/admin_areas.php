<!--
Proyecto:CONTROL PLAN DE PRODUCCION
Descripción: 
Autor: Josué Saravia - jsaravia@tata.com.gt
Fecha Inicio: 31-08-2018
-->

<?php 
	require("../login/seguridad.php");
	//$user = $_GET["name"];
?>

<!DOCTYPE html>
<html>

<body>

	<?php include("menu_nav.php"); ?>
	
	<main>
		<div class="row">
		</div>

		<div class="row">
			<div class="col s10 offset-s1">
				<form autocomplete="off" id="formArea">
					<div class="input-field">
						<i class="material-icons prefix grey-text">import_export</i>
						<input name="area" id="area" type="text" maxlength="50">
						<label for="area">Nombre del área o departamento (SIN ESPACIOS)</label>
						<input type="hidden" name="operacion" id="operacion" value="agregar">
						<input type="hidden" name="old_area" id="old_area" value="">
					</div>
					<div>
						<input type="submit" value="Agregar" class="btn col s2 grey left" />
					</div>
				</form>
			</div>	
		</div>

		<div class="row">
			<div class="col s10 offset-s1" id="">
				<div class="divider"></div>
				<table id="TableData" class="table responsive-table striped highlight">
					<thead>
						<tr>
							<th>No.</th>
							<th>Área/Departamento</th>
							<th></th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php require('../database/conn.php');

						header('Content-Type: text/html; charset=UTF-8');
						mysqli_set_charset($mysqli, "utf8");

						$query = mysqli_query($mysqli, "SELECT ORDINAL_POSITION AS NUM, COLUMN_NAME AS NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'PP_SEMANAL' AND ORDINAL_POSITION > 11;") 
						or die('error: '.mysqli_error($mysqli));
						
						$i = 1;
						while ($strData = mysqli_fetch_assoc($query)) {	?>
							<tr>
								<td><?php print $i ?></td>
								<td><?php print $strData["NAME"]; ?></td>
								<td class="tooltipped" data-position="left" data-tooltip="¿Editar nombre de área?" style="cursor: pointer;" onclick="EditColumn(<?php print "'".$strData["NAME"]."'"; ?>)"><i class="material-icons grey-text">edit</i></td>
								<td class="tooltipped" data-position="left" data-tooltip="¿Eliminar area (se eliminaran los registros)?" style="cursor: pointer;" onclick="DeleteColumn(<?php print "'".$strData["NAME"]."'"; ?>)"><i class="material-icons grey-text">delete</i></td>
							</tr>
							<?php $i+=1; ?>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>

	</main>

	<script src="../js/jquery-2.1.1.min.js"></script><!--Import jQuery before materialize.js-->
	<script src="../js/materialize.min.js"></script><!-- Importar funciones de materialize css -->
	<script src="../js/jquery.dataTables.min.js"></script><!-- pluggin de jquery para hacer tablas dinámicas -->
	<script src="../js/admin_usuarios.js"></script>
	<script src="../js/materializeEffects.js"></script><!-- Funciones de jquery que necesita materializecss -->

	<script type="text/javascript">

		$(document).on("ready", function(){
			mostrarData();

			$(document).ready(function (e) {

				$("#formArea").on('submit',(function(e) {
					e.preventDefault();
					$.ajax({
						url: "../database/process_area.php",
						type: "POST",
						data:  new FormData(this),
						contentType: false,
						cache: false,
						processData:false,
						success: function(data)
						{
							//AlertToast('Columna agregada con éxito!','done','green');
							location.reload();
						}
					});
				}));
			});
		});


		var mostrarData = function(){
			var table = $('#TableData').DataTable({
				"destroy":true,
				"bPaginate": true,
				"bSort": true,
		        //"aoColumnDefs": [ { 'bSortable': false, 'aTargets': [ 2,4,5,8,9,10 ] } ],
		        "bJQueryUI": false,
		        "lengthMenu": [[5, 8, 10, 20, 25, 50, -1], [5, 8, 10, 20, 25, 50, "Todos"]],
		        "iDisplayLength": -1,
		        "bProcessing": false,
		        "language": {
		        	"sProcessing":     '<div class="progress"><div class="indeterminate"></div></div>',
		        	"sLengthMenu":     "Mostrar _MENU_ <br>",
		        	"sZeroRecords":    "No se encontraron datos",
		        	"sEmptyTable":     "Ningún dato disponible en esta tabla",
		        	"sInfo":           "Mostrando datos del _START_ al _END_ de un total de _TOTAL_",
		        	"sInfoEmpty":      "Mostrando datos del 0 al 0 de un total de 0",
		        	"sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
		        	"sInfoPostFix":    "",
		        	"sSearch":         "<br>",
		        	"sSearchPlaceholder": " BUSCAR",
		        	"sUrl":            "",
		        	"sInfoThousands":  ",",
		        	"sLoadingRecords": '<div class="progress"><div class="indeterminate"></div></div>',
		        	"oPaginate": {
		        		"sFirst":    "Primero",
		        		"sLast":     "Último",
		        		"sNext":     "Siguiente",
		        		"sPrevious": "Anterior"
		        	}
		        }
		    });
			$('select').addClass("browser-default");
		}

		function AlertToast(message,icon,color){
			var toastHTML = '<span>'+message+'&nbsp;</span><i class="material-icons'+' '+color+'-text'+'">'+icon+'</i>';
			return M.toast({html: toastHTML, classes: 'rounded'});
		}

		function DeleteColumn(col){
			console.log(col);
			var op = confirm("¿Desea eliminar el area seleccionado?");
			if (op == true) {
				var parametros = {
					"area" : col,
					"operacion" : "eliminar"
				};
				var $envio = $.ajax({
					url: "../database/process_area.php",
					data: parametros,
					type: 'POST'
				});
				$envio.success(function(){
					location.reload();
				});
			}
		} 

		function EditColumn(col){
			$("#operacion").val("editar");
			$("#old_area").val(col);
			$("#area").focus();
			$("#area").val(col);
		}

	</script>


</body>
</html>