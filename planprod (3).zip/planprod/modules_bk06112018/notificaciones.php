<!DOCTYPE html>
<html>

<body>

	<?php include("menu_nav.php"); ?>

	<div class="container">
		<div id="wrapper">
			<br>
			<p>Notificaciones con PUSH JS</p>
			<button class="btn" id="notify-button">Notificarme</button>
			<button class="btn" id="check">Permiso</button>
		</div>	
	</div>

	

	<script type="text/javascript">
		$("#notify-button").click(function(){
			//Push.create("Hola mundo");

			//Push.Permission.DEFAULT; // 'default'
			Push.Permission.GRANTED; // 'granted'
			//Push.Permission.DENIED; // 'denied'


			Push.create("Despacho pendiente para Línea Ensamble 1", {
			    body: "Troqueles y clishes pendientes de despachar para el día de hoy.",
			    icon: '../images/logo/calendar1.png',
			    vibrate: [500,100],
			    //timeout: 10000,
			    requireInteraction: true,
			    onClick: function () {
			    	window.location="http://pdm.tata/toolkits/planprod/modules/table-admin.php";
			        window.focus();
			        this.close();
			    }
			});


		});

		$("#check").click(function(){
			alert(Push.Permission.has());
		});
	</script>



</body>
</html>